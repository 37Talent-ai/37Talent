import React from 'react';
import { motion } from 'framer-motion';
import { Globe, ArrowRight, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function IndustryRetail() {
  return (
    <div className="min-h-screen">
      {/* Hero */}
      <div className="bg-gradient-to-br from-[#202020] via-[#c00060] to-[#202020] py-20">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Globe className="w-16 h-16 text-[#ff47a3] mb-6" />
            <h1 className="text-5xl font-bold text-white mb-6">
              Retail & E-commerce
            </h1>
            <p className="text-xl text-gray-400 max-w-3xl">
              Connecting retail and e-commerce businesses with talent that drives growth.
            </p>
          </motion.div>
        </div>
      </div>

      {/* Content */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-12 items-start">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl font-bold text-gray-900 mb-6">
                E-commerce Excellence
              </h2>
              <p className="text-gray-600 mb-6 leading-relaxed">
                The retail landscape has transformed. Today's successful retailers combine physical presence with digital innovation. We find talent that understands omnichannel strategies, customer experience, and the technology driving modern commerce.
              </p>
              <p className="text-gray-600 mb-6 leading-relaxed">
                From merchandising to marketplace management, we connect you with professionals who can navigate the complexities of retail and e-commerce.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <div className="bg-gray-50 rounded-2xl p-8">
                <h3 className="text-xl font-bold text-gray-900 mb-6">Key Roles We Fill</h3>
                <ul className="space-y-4">
                  {[
                    'E-commerce Managers & Directors',
                    'Digital Merchandisers',
                    'Marketplace Specialists (Amazon, eBay, etc.)',
                    'Retail Media Strategists',
                    'Supply Chain & Logistics Managers',
                    'Customer Experience Specialists',
                    'E-commerce Developers & Engineers',
                    'Conversion Rate Optimization (CRO) Experts',
                  ].map((role, i) => (
                    <li key={i} className="flex items-center gap-3">
                      <CheckCircle2 className="w-5 h-5 text-[#ff0080] shrink-0" />
                      <span className="text-gray-700">{role}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">
            Transform Your Retail Team
          </h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            Let's discuss how we can help you find the right talent for your retail business.
          </p>
          <Link to={createPageUrl('Contact')}>
            <Button className="bg-gradient-to-r from-[#ff0080] to-[#c00060] hover:from-[#c00060] hover:to-[#ff0080] text-white px-8 py-6 rounded-xl font-semibold">
              Get in Touch
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
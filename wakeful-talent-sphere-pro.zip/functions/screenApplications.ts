import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { applicationText, jobId } = await req.json();

    if (!applicationText || !jobId) {
      return Response.json({ error: 'Missing applicationText or jobId' }, { status: 400 });
    }

    // Get job details
    const jobs = await base44.asServiceRole.entities.Job.filter({ id: jobId });
    const job = jobs[0];

    if (!job) {
      return Response.json({ error: 'Job not found' }, { status: 404 });
    }

    // Use LLM to screen and rank the application
    const screeningResult = await base44.integrations.Core.InvokeLLM({
      prompt: `You are an expert recruiter. Analyze this job application/resume against the job requirements and provide a structured assessment.

JOB DETAILS:
Title: ${job.title}
Description: ${job.description}
Requirements: ${job.requirements?.join(', ') || 'None specified'}
Category: ${job.category}

APPLICANT RESUME/APPLICATION:
${applicationText}

Provide your analysis in this exact JSON format:
{
  "overall_score": <number 0-100>,
  "skills_match": <number 0-100>,
  "experience_match": <number 0-100>,
  "qualifications_match": <number 0-100>,
  "key_strengths": [<array of 3-5 matching points>],
  "gaps": [<array of any significant gaps, or empty array>],
  "recommendation": "<STRONG FIT | GOOD FIT | MODERATE FIT | WEAK FIT>",
  "summary": "<2-3 sentence professional summary of why they are/aren't a fit>"
}`,
      response_json_schema: {
        type: 'object',
        properties: {
          overall_score: { type: 'number' },
          skills_match: { type: 'number' },
          experience_match: { type: 'number' },
          qualifications_match: { type: 'number' },
          key_strengths: { type: 'array', items: { type: 'string' } },
          gaps: { type: 'array', items: { type: 'string' } },
          recommendation: { type: 'string' },
          summary: { type: 'string' }
        },
        required: ['overall_score', 'skills_match', 'experience_match', 'qualifications_match', 'key_strengths', 'gaps', 'recommendation', 'summary']
      }
    });

    return Response.json({
      success: true,
      screening: screeningResult,
      job_title: job.title
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});
import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import SEOHead from '@/components/SEOHead';
import SchemaMarkup from '@/components/SchemaMarkup';

import HeroSection from '@/components/home/HeroSection';
import ClientsSlider from '@/components/home/ClientsSlider';
import FeaturedJobs from '@/components/home/FeaturedJobs';
import ServicesSection from '@/components/home/ServicesSection';
import StatsSection from '@/components/home/StatsSection';
import TestimonialsSection from '@/components/home/TestimonialsSection';
import CTASection from '@/components/home/CTASection';

export default function Home() {
  const { data: jobs, isLoading } = useQuery({
    queryKey: ['jobs', 'featured'],
    queryFn: () => base44.entities.Job.list('-created_date', 10),
    initialData: [],
  });

  return (
    <div>
      <SEOHead 
        title="37Talent | Recruitment & Talent Solutions | Sydney, Australia"
        description="37Talent delivers expert recruitment, talent advisory, and executive search services across Australia. Trusted by leading organisations for top talent solutions. Contact us today."
        canonical="https://37talent.com.au/"
      />
      <SchemaMarkup />
      <HeroSection />
      <ClientsSlider />
      <FeaturedJobs jobs={jobs} isLoading={isLoading} />
      <ServicesSection />
      <StatsSection />
      <TestimonialsSection />
      <CTASection />
    </div>
  );
}
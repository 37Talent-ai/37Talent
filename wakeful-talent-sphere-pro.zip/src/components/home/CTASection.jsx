import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Users, Briefcase } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function CTASection() {
  return (
    <section className="py-20" style={{ backgroundColor: '#062D32' }}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-8">
          {/* For Job Seekers */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative group"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-[#ff0080] to-[#c00060] rounded-3xl transform group-hover:scale-[1.02] transition-transform duration-300" />
            <div className="relative bg-gradient-to-r from-[#202020] to-[#c00060] rounded-3xl p-8 md:p-10 h-full">
              <div className="w-14 h-14 bg-white/10 rounded-xl flex items-center justify-center mb-6">
                <Briefcase className="w-7 h-7 text-[#ff47a3]" />
              </div>
              <h3 className="text-2xl md:text-3xl font-bold text-white mb-4">
                Looking for Your Next Role?
              </h3>
              <p className="text-[#ffebf5] text-lg mb-8 leading-relaxed">
                Browse thousands of opportunities across technology, digital, and government sectors. 
                Let us help you find your perfect fit.
              </p>
              <Link to={createPageUrl('Jobs')}>
                <Button className="bg-white text-[#ff0080] hover:bg-[#ffebf5] px-6 py-5 rounded-xl font-semibold group/btn">
                  Search Jobs
                  <ArrowRight className="ml-2 w-5 h-5 group-hover/btn:translate-x-1 transition-transform" />
                </Button>
              </Link>
            </div>
          </motion.div>

          {/* For Employers */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative group"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-[#202020] to-[#c00060] rounded-3xl transform group-hover:scale-[1.02] transition-transform duration-300" />
            <div className="relative bg-gradient-to-r from-[#202020] to-[#c00060] rounded-3xl p-8 md:p-10 h-full">
              <div className="w-14 h-14 bg-white/10 rounded-xl flex items-center justify-center mb-6">
                <Users className="w-7 h-7 text-[#ff47a3]" />
              </div>
              <h3 className="text-2xl md:text-3xl font-bold text-white mb-4">
                Looking to Hire Top Talent?
              </h3>
              <p className="text-gray-400 text-lg mb-8 leading-relaxed">
                Partner with us to access exceptional candidates who will drive your business forward. 
                We make hiring simple and effective.
              </p>
              <Link to={createPageUrl('Contact')}>
                <Button className="bg-gradient-to-r from-[#ff0080] to-[#c00060] text-white hover:from-[#c00060] hover:to-[#ff0080] px-6 py-5 rounded-xl font-semibold group/btn">
                  Get in Touch
                  <ArrowRight className="ml-2 w-5 h-5 group-hover/btn:translate-x-1 transition-transform" />
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
import React from 'react';
import { CheckCircle2, AlertCircle, TrendingUp, Users } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

const recommendationColors = {
  'STRONG FIT': 'bg-green-500/10 text-green-700 border-green-200',
  'GOOD FIT': 'bg-blue-500/10 text-blue-700 border-blue-200',
  'MODERATE FIT': 'bg-amber-500/10 text-amber-700 border-amber-200',
  'WEAK FIT': 'bg-red-500/10 text-red-700 border-red-200'
};

const getScoreColor = (score) => {
  if (score >= 80) return 'text-green-600';
  if (score >= 60) return 'text-blue-600';
  if (score >= 40) return 'text-amber-600';
  return 'text-red-600';
};

export default function ScreeningResult({ screening, jobTitle }) {
  if (!screening) return null;

  return (
    <div className="bg-white rounded-xl border border-gray-200 p-6 space-y-6">
      {/* Header */}
      <div className="space-y-4">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Application Screening</h3>
            <p className="text-sm text-gray-500 mt-1">for {jobTitle}</p>
          </div>
          <Badge className={`${recommendationColors[screening.recommendation]} border`}>
            {screening.recommendation}
          </Badge>
        </div>
      </div>

      {/* Overall Score */}
      <div className="bg-gradient-to-r from-gray-50 to-gray-100 rounded-lg p-4">
        <div className="flex items-center justify-between mb-2">
          <span className="font-semibold text-gray-700">Overall Match Score</span>
          <span className={`text-3xl font-bold ${getScoreColor(screening.overall_score)}`}>
            {screening.overall_score}%
          </span>
        </div>
        <Progress value={screening.overall_score} className="h-2" />
      </div>

      {/* Score Breakdown */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'Skills Match', score: screening.skills_match },
          { label: 'Experience', score: screening.experience_match },
          { label: 'Qualifications', score: screening.qualifications_match }
        ].map((item) => (
          <div key={item.label} className="bg-gray-50 rounded-lg p-3">
            <div className="text-xs text-gray-600 mb-2">{item.label}</div>
            <div className={`text-2xl font-bold ${getScoreColor(item.score)}`}>
              {item.score}%
            </div>
            <Progress value={item.score} className="h-1 mt-2" />
          </div>
        ))}
      </div>

      {/* Summary */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <p className="text-sm text-blue-900">{screening.summary}</p>
      </div>

      {/* Key Strengths */}
      {screening.key_strengths?.length > 0 && (
        <div>
          <div className="flex items-center gap-2 mb-3">
            <CheckCircle2 className="w-5 h-5 text-green-600" />
            <h4 className="font-semibold text-gray-900">Key Strengths</h4>
          </div>
          <ul className="space-y-2 ml-7">
            {screening.key_strengths.map((strength, idx) => (
              <li key={idx} className="text-sm text-gray-700">• {strength}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Gaps */}
      {screening.gaps?.length > 0 && (
        <div>
          <div className="flex items-center gap-2 mb-3">
            <AlertCircle className="w-5 h-5 text-amber-600" />
            <h4 className="font-semibold text-gray-900">Experience Gaps</h4>
          </div>
          <ul className="space-y-2 ml-7">
            {screening.gaps.map((gap, idx) => (
              <li key={idx} className="text-sm text-gray-700">• {gap}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
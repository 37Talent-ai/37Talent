import React from 'react';
import { motion } from 'framer-motion';
import { Cloud, ArrowRight, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function IndustrySaaS() {
  return (
    <div className="min-h-screen">
      {/* Hero */}
      <div className="bg-gradient-to-br from-[#202020] via-[#c00060] to-[#202020] py-20">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Cloud className="w-16 h-16 text-[#ff47a3] mb-6" />
            <h1 className="text-5xl font-bold text-white mb-6">
              SaaS
            </h1>
            <p className="text-xl text-gray-400 max-w-3xl">
              Building high-growth SaaS teams that scale with your business.
            </p>
          </motion.div>
        </div>
      </div>

      {/* Content */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-12 items-start">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl font-bold text-gray-900 mb-6">
                Powering SaaS Growth
              </h2>
              <p className="text-gray-600 mb-6 leading-relaxed">
                SaaS companies need teams that can move fast, innovate constantly, and scale rapidly. We specialize in finding technical and go-to-market talent for high-growth SaaS businesses, from early-stage startups to established platforms.
              </p>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Our network includes product managers, engineers, sales leaders, and customer success experts who understand the unique challenges of subscription-based business models.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <div className="bg-gray-50 rounded-2xl p-8">
                <h3 className="text-xl font-bold text-gray-900 mb-6">Key Roles We Fill</h3>
                <ul className="space-y-4">
                  {[
                    'Product Managers & Product Owners',
                    'Software Engineers (Frontend, Backend, Full-Stack)',
                    'DevOps & Cloud Infrastructure Engineers',
                    'SaaS Sales & Account Executives',
                    'Customer Success Managers',
                    'Growth & Marketing Specialists',
                    'Data Engineers & Analytics',
                    'UX/UI Designers',
                  ].map((role, i) => (
                    <li key={i} className="flex items-center gap-3">
                      <CheckCircle2 className="w-5 h-5 text-[#ff0080] shrink-0" />
                      <span className="text-gray-700">{role}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">
            Scale Your SaaS Team
          </h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            Let's discuss how we can help you build a world-class team.
          </p>
          <Link to={createPageUrl('Contact')}>
            <Button className="bg-gradient-to-r from-[#ff0080] to-[#c00060] hover:from-[#c00060] hover:to-[#ff0080] text-white px-8 py-6 rounded-xl font-semibold">
              Get in Touch
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
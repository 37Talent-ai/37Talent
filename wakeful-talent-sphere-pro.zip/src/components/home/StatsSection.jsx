import React from 'react';
import { motion, useInView } from 'framer-motion';
import { useRef, useState, useEffect } from 'react';

const stats = [
  { value: 5, suffix: '+', label: 'Years in Business' },
  { value: 200, suffix: '+', label: 'Successful Placements' },
  { value: 100, suffix: '+', label: 'Partner Companies' },
  { value: 98, suffix: '%', label: 'Client Satisfaction' },
];

function AnimatedNumber({ value, suffix }) {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  useEffect(() => {
    if (isInView) {
      const duration = 2000;
      const steps = 60;
      const increment = value / steps;
      let current = 0;
      
      const timer = setInterval(() => {
        current += increment;
        if (current >= value) {
          setCount(value);
          clearInterval(timer);
        } else {
          setCount(Math.floor(current));
        }
      }, duration / steps);

      return () => clearInterval(timer);
    }
  }, [isInView, value]);

  return (
    <span ref={ref}>
      {count.toLocaleString()}{suffix}
    </span>
  );
}

export default function StatsSection() {
  return (
    <section className="py-20 bg-gradient-to-br from-[#202020] via-[#c00060] to-[#202020] relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-[#062D32]">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-[#ff0080]/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-[#c00060]/10 rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Trusted by Industry Leaders
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Our track record speaks for itself. We've built lasting relationships 
            with clients and candidates across the globe.
          </p>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="text-center"
            >
              <div className="text-4xl md:text-5xl lg:text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-[#ff47a3] to-[#c00060] mb-2">
                <AnimatedNumber value={stat.value} suffix={stat.suffix} />
              </div>
              <div className="text-gray-400 font-medium">{stat.label}</div>
            </motion.div>
          ))}
        </div>

        {/* Client Logos */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
          className="mt-32"
        >
          <p className="text-center text-gray-500 text-sm uppercase tracking-wider mb-8">
            Trusted by leading organisations
          </p>
          <div className="grid grid-cols-2 md:flex md:flex-wrap justify-center items-center gap-4 md:gap-12 opacity-50">
            {/* Placeholder for client logos - using text for now */}
            {['Data Science', 'Technology', 'Retail & Ecommerce', 'Media & Entertainment'].map((industry) => (
              <div 
                key={industry} 
                className="text-gray-400 font-semibold text-sm md:text-lg text-center"
              >
                {industry}
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
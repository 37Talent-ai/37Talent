import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useMutation } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock,
  Send,
  CheckCircle2,
  Linkedin,
  Twitter,
  Facebook,
  Upload,
  X,
  Loader2,
  Search,
  ArrowRight
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from 'sonner';
import ScreeningResult from '@/components/ScreeningResult';

const offices = [
  {
    city: 'Sydney',
    address: '81-83 Campbell Street, Surry Hills, NSW 2010',
    phone: '+61 2 7241 4413',
    email: 'info@37talent.com.au',
  },
];

export default function Contact() {
  const [searchQuery, setSearchQuery] = useState('');
  const [particles, setParticles] = useState([]);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    inquiry_type: '',
    message: '',
    attachment_url: '',
  });
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [uploadedFile, setUploadedFile] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [screeningResult, setScreeningResult] = useState(null);
  const [isScreening, setIsScreening] = useState(false);

  const handleSearch = () => {
    window.location.href = createPageUrl('Jobs') + `?search=${encodeURIComponent(searchQuery)}`;
  };

  React.useEffect(() => {
    const newParticles = Array.from({ length: 50 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 4 + 1,
      duration: Math.random() * 20 + 10,
      delay: Math.random() * 5,
    }));
    setParticles(newParticles);
  }, []);

  React.useEffect(() => {
    const handleMouseMove = (e) => {
      setMousePosition({
        x: (e.clientX / window.innerWidth) * 20 - 10,
        y: (e.clientY / window.innerHeight) * 20 - 10,
      });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const mutation = useMutation({
    mutationFn: (data) => base44.entities.ContactInquiry.create(data),
    onSuccess: () => {
      setIsSubmitted(true);
      setFormData({
        name: '',
        email: '',
        phone: '',
        inquiry_type: '',
        message: '',
        attachment_url: '',
      });
      setUploadedFile(null);
    },
    onError: () => {
      toast.error('Failed to send message. Please try again.');
    },
  });

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData({ ...formData, attachment_url: file_url });
      setUploadedFile({ name: file.name, url: file_url });
      toast.success('File uploaded successfully');
    } catch (error) {
      toast.error('Failed to upload file');
    } finally {
      setIsUploading(false);
    }
  };

  const handleRemoveFile = () => {
    setUploadedFile(null);
    setFormData({ ...formData, attachment_url: '' });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    mutation.mutate(formData);
  };

  const handleScreenApplication = async () => {
    if (!uploadedFile || !formData.inquiry_type) {
      toast.error('Please upload a resume and select an inquiry type');
      return;
    }

    setIsScreening(true);
    try {
      const response = await base44.functions.invoke('screenApplications', {
        applicationText: `Name: ${formData.name}\nEmail: ${formData.email}\nPhone: ${formData.phone}\n\nResume attached: ${uploadedFile.name}`,
        jobId: 'general'
      });
      setScreeningResult(response.data.screening);
      toast.success('Application screened successfully');
    } catch (error) {
      toast.error('Failed to screen application');
    } finally {
      setIsScreening(false);
    }
  };

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <div className="relative min-h-screen overflow-hidden flex items-center bg-[#202020]">
        <div className="absolute inset-0 bg-gradient-to-b from-[#202020] to-[#1a1a1a]" />

        {/* Animated Background Particles */}
        <div className="absolute inset-0">
          {particles.map((particle) => (
            <motion.div
              key={particle.id}
              className="absolute rounded-full bg-[#ff0080]/30"
              style={{
                left: `${particle.x}%`,
                top: `${particle.y}%`,
                width: particle.size,
                height: particle.size,
              }}
              animate={{
                y: [0, -30, 0],
                x: [0, Math.random() * 20 - 10, 0],
                opacity: [0.3, 0.8, 0.3],
                scale: [1, 1.2, 1],
              }}
              transition={{
                duration: particle.duration,
                delay: particle.delay,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />
          ))}
        </div>

        {/* 3D Animated Logo Background */}
        <motion.div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] opacity-10"
          style={{
            perspective: '1000px',
            transformStyle: 'preserve-3d',
          }}
          animate={{
            rotateY: 360,
            rotateX: [0, 10, 0, -10, 0],
            z: [0, 50, 0, -50, 0],
          }}
          transition={{
            rotateY: { duration: 20, repeat: Infinity, ease: "linear" },
            rotateX: { duration: 8, repeat: Infinity, ease: "easeInOut" },
            z: { duration: 6, repeat: Infinity, ease: "easeInOut" },
          }}
        >
          <motion.img
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/f447e746e_Inverse2x.png"
            alt="37Talent logo"
            className="w-full h-full object-contain"
            style={{
              filter: 'drop-shadow(0 0 60px rgba(255, 0, 128, 0.6))',
              transformStyle: 'preserve-3d',
            }}
            animate={{
              scale: [1, 1.1, 1],
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
        </motion.div>

        {/* Gradient Orbs with Parallax */}
        <motion.div 
          className="absolute top-1/4 right-1/4 w-96 h-96 bg-[#ff0080]/20 rounded-full blur-3xl"
          animate={{
            scale: [1, 1.2, 1],
            x: mousePosition.x * 2,
            y: mousePosition.y * 2,
          }}
          transition={{ scale: { duration: 4, repeat: Infinity }, x: { duration: 0.5 }, y: { duration: 0.5 } }}
        />
        <motion.div 
          className="absolute bottom-1/4 left-1/4 w-72 h-72 bg-[#c00060]/20 rounded-full blur-3xl"
          animate={{
            scale: [1, 1.3, 1],
            x: mousePosition.x * -1.5,
            y: mousePosition.y * -1.5,
          }}
          transition={{ scale: { duration: 5, repeat: Infinity }, x: { duration: 0.5 }, y: { duration: 0.5 } }}
        />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12 lg:py-16 pt-[15vh] sm:pt-[20vh] md:pt-12 lg:pt-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl mx-auto text-center"
          >
            <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4 sm:mb-6">
              Get in Touch
            </h1>
            <p className="text-sm sm:text-base md:text-lg lg:text-xl text-white/90 leading-relaxed mb-6 sm:mb-10">
              Have a question or want to discuss how we can help? 
              We'd love to hear from you.
            </p>


            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.5 }}
              className="flex flex-col sm:flex-row flex-wrap gap-3 sm:gap-4 justify-center px-2 sm:px-0"
            >
              <Link to={createPageUrl('Jobs')} className="w-full sm:w-auto">
                <motion.div whileHover={{ scale: 1.05, x: 5 }} whileTap={{ scale: 0.95 }} className="w-full">
                  <Button 
                    variant="outline" 
                    className="border-2 border-white text-white hover:bg-white hover:text-[#c00060] px-4 sm:px-6 py-4 sm:py-5 rounded-xl group backdrop-blur-md bg-white/15 w-full text-sm sm:text-base"
                  >
                    Browse All Jobs
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </motion.div>
              </Link>
              <Link to={createPageUrl('Home')} className="w-full sm:w-auto">
                <motion.div whileHover={{ scale: 1.05, x: 5 }} whileTap={{ scale: 0.95 }} className="w-full">
                  <Button 
                    className="bg-white/25 backdrop-blur-md border-2 border-white text-white hover:bg-white hover:text-[#c00060] px-4 sm:px-6 py-4 sm:py-5 rounded-xl font-semibold shadow-lg w-full text-sm sm:text-base"
                  >
                    Back to Home
                  </Button>
                </motion.div>
              </Link>
            </motion.div>
          </motion.div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#202020] to-transparent" />
      </div>

      {/* Contact Section */}
      <section className="py-16 md:py-20" style={{ backgroundColor: '#062D32' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid lg:grid-cols-2 gap-8 md:gap-12">
            {/* Contact Form */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
            >
              <div className="bg-white rounded-2xl sm:rounded-3xl p-6 sm:p-8 shadow-sm border border-gray-100">
                {isSubmitted ? (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="text-center py-12"
                  >
                    <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
                      <CheckCircle2 className="w-8 h-8 text-emerald-500" />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">Message Sent!</h3>
                    <p className="text-gray-600 mb-6">
                      Thank you for reaching out. We'll get back to you within 24 hours.
                    </p>
                    <Button 
                      onClick={() => setIsSubmitted(false)}
                      variant="outline"
                    >
                      Send Another Message
                    </Button>
                  </motion.div>
                ) : (
                  <>
                    <h2 className="text-2xl font-bold text-gray-900 mb-6">Send Us a Message</h2>
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div className="grid sm:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="name">Full Name *</Label>
                          <Input
                            id="name"
                            value={formData.name}
                            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                            required
                            className="mt-1"
                            placeholder="John Doe"
                          />
                        </div>
                        <div>
                          <Label htmlFor="email">Email *</Label>
                          <Input
                            id="email"
                            type="email"
                            value={formData.email}
                            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                            required
                            className="mt-1"
                            placeholder="john@example.com"
                          />
                        </div>
                      </div>

                      <div className="grid sm:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="phone">Phone</Label>
                          <Input
                            id="phone"
                            value={formData.phone}
                            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                            className="mt-1"
                            placeholder="+61 400 000 000"
                          />
                        </div>
                        <div>
                          <Label htmlFor="inquiry_type">Inquiry Type *</Label>
                          <Select 
                            value={formData.inquiry_type} 
                            onValueChange={(value) => setFormData({ ...formData, inquiry_type: value })}
                          >
                            <SelectTrigger className="mt-1">
                              <SelectValue placeholder="Select type" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Hiring">I want to hire talent</SelectItem>
                              <SelectItem value="Job Seeker">I'm looking for a job</SelectItem>
                              <SelectItem value="Submit Resume">Submit resume</SelectItem>
                              <SelectItem value="Partnership">Partnership inquiry</SelectItem>
                              <SelectItem value="General">General inquiry</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="message">Message *</Label>
                        <Textarea
                          id="message"
                          value={formData.message}
                          onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                          required
                          className="mt-1 h-32"
                          placeholder="Tell us how we can help..."
                        />
                      </div>

                      <div>
                        <Label htmlFor="attachment">Attach Resume (optional)</Label>
                        <div className="mt-1">
                          {uploadedFile ? (
                            <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-lg border border-gray-200">
                              <div className="flex-1 flex items-center gap-2 text-sm text-gray-700">
                                <Upload className="w-4 h-4 text-gray-400" />
                                {uploadedFile.name}
                              </div>
                              <button
                                type="button"
                                onClick={handleRemoveFile}
                                className="text-gray-400 hover:text-gray-600"
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </div>
                          ) : (
                            <label className="flex items-center justify-center gap-2 p-4 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-[#ff0080] hover:bg-gray-50 transition-colors">
                              <Upload className="w-5 h-5 text-gray-400" />
                              <span className="text-sm text-gray-600">
                                {isUploading ? 'Uploading...' : 'Click to upload or drag and drop'}
                              </span>
                              <input
                                id="attachment"
                                type="file"
                                className="hidden"
                                onChange={handleFileUpload}
                                disabled={isUploading}
                                accept=".pdf,.doc,.docx"
                              />
                            </label>
                          )}
                        </div>
                      </div>

                      <div className="space-y-3">
                        <Button 
                          type="submit" 
                          className="w-full bg-gradient-to-r from-[#ff0080] to-[#c00060] hover:from-[#c00060] hover:to-[#ff0080] py-6 rounded-xl"
                          disabled={mutation.isPending}
                        >
                          {mutation.isPending ? 'Sending...' : 'Send Message'}
                          <Send className="ml-2 w-4 h-4" />
                        </Button>
                        {uploadedFile && formData.inquiry_type === 'Job Seeker' && (
                          <Button
                            type="button"
                            variant="outline"
                            className="w-full py-6 rounded-xl"
                            onClick={handleScreenApplication}
                            disabled={isScreening}
                          >
                            {isScreening ? (
                              <>
                                <Loader2 className="mr-2 w-4 h-4 animate-spin" />
                                Screening...
                              </>
                            ) : (
                              'Screen My Application'
                            )}
                          </Button>
                        )}
                      </div>
                    </form>
                  </>
                  )}
                  </div>
                  {screeningResult && (
                  <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-6"
                  >
                  <ScreeningResult screening={screeningResult} jobTitle="Application" />
                  </motion.div>
                  )}
                  </motion.div>

            {/* Contact Info */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-8"
            >
              {/* Quick Contact */}
              <div className="bg-gradient-to-br from-[#202020] via-[#c00060] to-[#202020] rounded-3xl p-8 text-white">
                <h3 className="text-xl font-bold mb-6">Quick Contact</h3>
                <div className="space-y-4">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center">
                      <Phone className="w-5 h-5 text-[#ff47a3]" />
                    </div>
                    <div>
                      <div className="text-gray-400 text-sm">Call us</div>
                      <div className="font-semibold">+61 2 7241 4413</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center">
                      <Mail className="w-5 h-5 text-[#ff47a3]" />
                    </div>
                    <div>
                      <div className="text-gray-400 text-sm">Email us</div>
                      <div className="font-semibold">info@37talent.com.au</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center">
                      <Clock className="w-5 h-5 text-[#ff47a3]" />
                    </div>
                    <div>
                      <div className="text-gray-400 text-sm">Business hours</div>
                      <div className="font-semibold">Mon - Fri, 9am - 6pm</div>
                    </div>
                  </div>
                </div>

                <div className="mt-8 pt-6 border-t border-white/10">
                  <div className="text-gray-400 text-sm mb-4">Follow us</div>
                  <div className="flex gap-3">
                    <a href="https://linkedin.com/company/37talent/?originalSubdomain=au" target="_blank" rel="noopener noreferrer" className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-[#ff0080]/20 transition-colors">
                      <Linkedin className="w-5 h-5" />
                    </a>
                    <a href="#" className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-[#ff0080]/20 transition-colors">
                      <Twitter className="w-5 h-5" />
                    </a>
                    <a href="#" className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-[#ff0080]/20 transition-colors">
                      <Facebook className="w-5 h-5" />
                    </a>
                  </div>
                </div>
              </div>


            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
}
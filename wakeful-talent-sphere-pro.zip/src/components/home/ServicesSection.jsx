import React from 'react';
import { motion } from 'framer-motion';
import { 
  Users, 
  Laptop, 
  Building2, 
  Lightbulb, 
  ArrowRight,
  Zap 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const services = [
  {
    icon: Building2,
    title: 'Media and Entertainment',
    description: 'Specialised recruitment for advertising agencies, digital marketing firms, brands, SaaS and ad tech companies with a focus on creative talent, performance marketing, and fast-paced digital innovation.',
    color: 'from-[#ff47a3] to-[#ff99cc]',
    bgColor: 'bg-[#ffebf5]',
    link: 'IndustryAdvertising',
  },
  {
    icon: Laptop,
    title: 'Technology Recruitment',
    description: 'Find exceptional tech talent from developers to CTOs. We understand the technical landscape and match skills with culture.',
    color: 'from-[#ff0080] to-[#c00060]',
    bgColor: 'bg-[#ffebf5]',
    link: 'Services',
  },
  {
    icon: Lightbulb,
    title: 'Digital Transformation',
    description: 'Navigate change with experts in digital strategy, change management, and innovation leadership.',
    color: 'from-[#c00060] to-[#ff47a3]',
    bgColor: 'bg-[#ffebf5]',
    link: 'Services',
  },
  {
    icon: Users,
    title: 'Executive Search',
    description: 'C-suite and senior leadership recruitment with a focus on strategic fit and long-term success.',
    color: 'from-[#c00060] to-[#ff0080]',
    bgColor: 'bg-[#ffebf5]',
    link: 'Services',
  },
];

function ServiceCard({ service, index }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="group"
    >
      <div className="relative bg-white rounded-2xl p-8 shadow-sm border border-gray-100 hover:shadow-xl transition-all duration-300 h-full">
        {/* Icon */}
        <div className={`w-14 h-14 ${service.bgColor} rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
          <service.icon className={`w-7 h-7 bg-gradient-to-r ${service.color} text-transparent`} style={{ stroke: 'url(#gradient)' }}>
            <defs>
              <linearGradient id="gradient">
                <stop offset="0%" stopColor="#06b6d4" />
                <stop offset="100%" stopColor="#14b8a6" />
              </linearGradient>
            </defs>
          </service.icon>
          <div className={`w-7 h-7 bg-gradient-to-r ${service.color} rounded-lg flex items-center justify-center -ml-7`}>
            <service.icon className="w-4 h-4 text-white" />
          </div>
        </div>

        {/* Content */}
        <h3 className="text-xl font-semibold text-gray-900 mb-3">
          {service.title}
        </h3>
        <p className="text-gray-600 leading-relaxed mb-6">
          {service.description}
        </p>

        {/* Link */}
        <Link 
          to={createPageUrl(service.link)} 
          className="inline-flex items-center text-[#ff0080] font-medium hover:text-[#c00060] group/link"
        >
          Learn more
          <ArrowRight className="ml-2 w-4 h-4 group-hover/link:translate-x-1 transition-transform" />
        </Link>
      </div>
    </motion.div>
  );
}

export default function ServicesSection() {
  return (
    <section className="py-20 relative overflow-hidden" style={{ backgroundColor: '#051619' }}>
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex flex-col lg:flex-row lg:items-end lg:justify-between mb-12"
        >
          <div className="mb-6 lg:mb-0">
            <div className="flex items-center gap-2 mb-4">
              <Zap className="w-5 h-5 text-[#ff0080]" />
              <span className="text-[#ff0080] font-medium uppercase tracking-wide text-sm">Our Services</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              How We Can Help You
            </h2>
            <p className="text-gray-300 text-lg max-w-2xl">
              Whether you're looking for your next career opportunity or building 
              a world-class team, we have the expertise to help.
            </p>
          </div>
          <Link to={createPageUrl('Services')}>
           <Button 
             className="bg-gradient-to-r from-[#ff0080] to-[#c00060] hover:from-[#c00060] hover:to-[#ff0080] text-white px-6 py-5 rounded-xl"
           >
              View All Services
              <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </Link>
        </motion.div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <ServiceCard key={service.title} service={service} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Quote, ChevronLeft, ChevronRight, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';

const testimonials = [
  {
    id: 1,
    content: "In 2021, we began working with Nick and his team on multiple vacancies created as a result of our growth. As we began working with 37Talent, we found a genuine team dedicated to understanding not just the roles we were trying to fill but also the types of individuals that would be valuable additions to our strong culture. Nick's hands-on approach to finding the perfect match for both employer and employee fit with our values. 37Talent has now become our preferred talent provider, with over 10 placements in the past 12 months alone. I have no hesitation in recommending 37Talent to any business looking for a true partner who delivers with efficiency, open communication & professionalism.",
    author: "Fiona Roberts",
    role: "Managing Director MiQ Digital | B&T 'Women in Media' and 'Women in Tech' Awards Executive Leader Finalist",
    rating: 5,
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/b58730108_1770020810373.jpeg",
  },
  {
    id: 2,
    content: "37Talent's service is highly efficient, timely, and thorough. They understand our organisation's culture and dynamics, consistently identifying candidates who precisely match the profiles we seek.",
    author: "Christopher Scudder",
    role: "Head of Agency Sales - Coles360",
    rating: 5,
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/031a5b1c1_1729052287240.jpeg",
  },
  {
    id: 3,
    content: "A valued partner in helping to build the TTD Sydney team – both client services and technical. Nick started working with The Trade Desk in 2014, and when I moved to Sydney in August of 2015 to build our first Engineering and Data Science presence in APAC/ANZ, I was introduced to Nick. Over the last seven years, Nick has been a valued partner in helping to build the TTD Sydney team – both client services and technical. Even as Nick has moved between agencies, we stuck with Nick, not the agencies. With Nick's help, we have grown our AU presence to nearly 80 staff.",
    author: "David Uchimoto",
    role: "Senior Director of Global R&D, The Trade Desk",
    rating: 5,
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/b2b6684a6_image.png",
  },
];

export default function TestimonialsSection() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const next = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prev = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <section className="py-20 bg-[#051619]">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            What People Say
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Don't just take our word for it. Here's what our clients and candidates have to say.
          </p>
        </motion.div>

        {/* Testimonial Carousel */}
        <div className="relative max-w-4xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              transition={{ duration: 0.3 }}
              className="bg-white rounded-3xl p-8 md:p-12 shadow-lg"
            >
              {/* Quote Icon */}
              <div className="w-12 h-12 bg-gradient-to-r from-cyan-500 to-teal-500 rounded-full flex items-center justify-center mb-6">
                <Quote className="w-6 h-6 text-white" />
              </div>

              {/* Rating */}
              <div className="flex gap-1 mb-6">
                {[...Array(testimonials[currentIndex].rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-amber-400 fill-amber-400" />
                ))}
              </div>

              {/* Content */}
              <p className="text-base md:text-lg text-gray-700 leading-relaxed mb-8">
                "{testimonials[currentIndex].content}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-4">
                <img
                  src={testimonials[currentIndex].image}
                  alt={testimonials[currentIndex].author}
                  className="w-14 h-14 rounded-full object-cover"
                />
                <div>
                  <div className="font-semibold text-gray-900">
                    {testimonials[currentIndex].author}
                  </div>
                  <div className="text-gray-500">
                    {testimonials[currentIndex].role}
                  </div>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Navigation */}
          <div className="flex justify-center gap-4 mt-8">
            <Button
              variant="outline"
              size="icon"
              onClick={prev}
              className="rounded-full border-gray-300 hover:bg-gray-100"
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${
                    index === currentIndex 
                      ? 'w-8 bg-gradient-to-r from-cyan-500 to-teal-500' 
                      : 'bg-gray-300 hover:bg-gray-400'
                  }`}
                />
              ))}
            </div>
            <Button
              variant="outline"
              size="icon"
              onClick={next}
              className="rounded-full border-gray-300 hover:bg-gray-100"
            >
              <ChevronRight className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
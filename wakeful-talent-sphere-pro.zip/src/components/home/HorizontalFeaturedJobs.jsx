import React, { useRef } from 'react';
import { motion } from 'framer-motion';
import { MapPin, DollarSign, ArrowRight, Briefcase, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const typeColors = {
  'Permanent': 'bg-[#c00060]/10 text-[#c00060] border-[#c00060]/30',
  'Contract': 'bg-[#ff47a3]/10 text-[#c00060] border-[#ff47a3]/30',
  'Part-time': 'bg-[#ff99cc]/10 text-[#ff0080] border-[#ff99cc]/30',
  'Casual': 'bg-[#ff0080]/10 text-[#c00060] border-[#ff0080]/30',
};

function JobCard({ job }) {
  return (
    <div className="flex-shrink-0 w-80">
      <div className="relative bg-white rounded-2xl p-6 shadow-sm border border-gray-100 hover:shadow-xl hover:border-cyan-200 transition-all duration-300 h-full flex flex-col">
        {/* Job Type Badge */}
        <div className="flex items-start justify-between mb-4">
          <Badge className={`${typeColors[job.type]} border font-medium`}>
            {job.type}
          </Badge>
          {job.featured && (
            <Badge className="bg-gradient-to-r from-[#ff0080] to-[#c00060] text-white border-0">
              Featured
            </Badge>
          )}
        </div>

        {/* Job Title */}
        <h3 className="text-lg font-semibold text-gray-900 mb-3 group-hover:text-[#ff0080] transition-colors line-clamp-2">
          {job.title}
        </h3>

        {/* Job Details */}
        <div className="space-y-2 mb-4 flex-1">
          {job.company && (
            <div className="flex items-center gap-2 text-gray-600">
              <Briefcase className="w-4 h-4 text-gray-400" />
              <span className="text-sm">{job.company}</span>
            </div>
          )}
          <div className="flex items-center gap-2 text-gray-600">
            <MapPin className="w-4 h-4 text-gray-400" />
            <span className="text-sm">{job.location}, {job.country}</span>
          </div>
          {job.salary && (
            <div className="flex items-center gap-2 text-gray-600">
              <DollarSign className="w-4 h-4 text-gray-400" />
              <span className="text-sm">{job.salary}</span>
            </div>
          )}
        </div>

        {/* Description */}
        <p className="text-gray-500 text-sm mb-4 line-clamp-3">
          {job.short_description || job.description}
        </p>

        {/* Apply Button */}
        <Link to={createPageUrl('JobDetails') + `?id=${job.id}`}>
          <Button 
            variant="ghost" 
            className="w-full justify-between text-[#ff0080] hover:text-[#c00060] hover:bg-[#ffebf5] group/btn"
          >
            View Details
            <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </div>
    </div>
  );
}

export default function HorizontalFeaturedJobs({ jobs, isLoading }) {
  const scrollContainerRef = useRef(null);
  const featuredJobs = jobs?.filter(j => j.featured).slice(0, 6) || [];
  const displayJobs = featuredJobs.length > 0 ? featuredJobs : jobs?.slice(0, 6) || [];

  const scroll = (direction) => {
    if (scrollContainerRef.current) {
      const scrollAmount = 400;
      scrollContainerRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth',
      });
    }
  };

  if (isLoading) {
    return (
      <section className="py-4 bg-pink-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <div className="h-10 bg-gray-200 rounded w-64 mx-auto mb-4 animate-pulse" />
            <div className="h-6 bg-gray-200 rounded w-96 mx-auto animate-pulse" />
          </div>
          <div className="flex gap-6">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="flex-shrink-0 w-80 bg-white rounded-2xl p-6 shadow-sm animate-pulse h-96" />
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Featured Jobs<span className="text-[#ff0080]">.</span>
          </h2>
        </motion.div>

        {/* Jobs Carousel */}
        {displayJobs.length > 0 ? (
          <div className="relative flex items-center gap-4">
            {/* Left Navigation */}
            <button
              onClick={() => scroll('left')}
              className="absolute -left-12 lg:left-0 z-10 p-2 rounded-lg bg-white border border-gray-200 hover:bg-gray-50 hover:border-[#ff0080] transition-all lg:relative lg:flex-shrink-0"
              aria-label="Scroll left"
            >
              <ChevronLeft className="w-5 h-5 text-gray-600" />
            </button>

            {/* Carousel Container */}
            <div
              ref={scrollContainerRef}
              className="flex gap-6 overflow-x-auto pb-4 scroll-smooth scrollbar-hide flex-1"
              style={{ scrollBehavior: 'smooth' }}
            >
              {displayJobs.map((job) => (
                <JobCard key={job.id} job={job} />
              ))}
            </div>

            {/* Right Navigation */}
            <button
              onClick={() => scroll('right')}
              className="absolute -right-12 lg:right-0 z-10 p-2 rounded-lg bg-white border border-gray-200 hover:bg-gray-50 hover:border-[#ff0080] transition-all lg:relative lg:flex-shrink-0"
              aria-label="Scroll right"
            >
              <ChevronRight className="w-5 h-5 text-gray-600" />
            </button>
          </div>
        ) : (
          <div className="text-center py-12 text-gray-500">
            No jobs available at the moment. Check back soon!
          </div>
        )}

        {/* View All Button */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <Link to={createPageUrl('Jobs')}>
            <Button className="bg-gradient-to-r from-[#ff0080] to-[#c00060] hover:from-[#c00060] hover:to-[#ff0080] text-white px-8 py-6 rounded-xl font-semibold shadow-lg shadow-[#ff0080]/25">
              View All Jobs
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
        </motion.div>
      </div>

      <style>{`
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </section>
  );
}
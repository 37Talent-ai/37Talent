import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Menu, 
  X, 
  ChevronDown,
  Phone,
  Mail,
  MapPin,
  Linkedin,
  Twitter,
  Facebook,
  Instagram,
  ArrowRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import Logo from '@/components/Logo';
import ChatWidget from '@/components/ChatWidget';

const navigation = [
  { name: 'Home', page: 'Home' },
  { name: 'About', page: 'About' },
  { name: 'Jobs', page: 'Jobs' },
  { name: 'Contact', page: 'Contact' },
];

export default function Layout({ children, currentPageName }) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location]);

  const isHomePage = currentPageName === 'Home';
  const isFullScreenHeroPage = ['Home', 'Contact', 'About'].includes(currentPageName);

  return (
    <div className="min-h-screen flex flex-col">
      <style>{`
        @media (max-width: 767px) {
          body { font-size: 1.05rem; }
          h1, .hero h1 { font-size: 2.2rem !important; margin-bottom: 1.5rem !important; }
          h2 { font-size: 1.8rem !important; margin-bottom: 2rem !important; }
          h3 { font-size: 1.3rem !important; }

          main > section, .section {
            padding: 2rem 1rem !important;
            margin-bottom: 2rem !important;
          }

          .container {
            padding-left: 1rem !important;
            padding-right: 1rem !important;
          }

          button {
            min-height: 44px;
            min-width: 44px;
          }

          /* Responsive grids */
          [class*="grid"] {
            grid-template-columns: 1fr !important;
          }

          /* Images - full width, maintain aspect ratio */
          img {
            max-width: 100%;
            height: auto;
            object-fit: cover;
          }

          /* Flex layouts - stack vertically */
          .flex.flex-row, .lg\\:flex-row, .md\\:flex-row {
            flex-direction: column !important;
          }

          /* Timeline and card layouts */
          .gap-8, .gap-12 {
            gap: 1rem !important;
          }

          /* Team cards - stack single column */
          .lg\\:grid-cols-4, .md\\:grid-cols-2 {
            grid-template-columns: 1fr !important;
            max-width: 90%;
            margin: 0 auto;
          }

          /* Ensure sections don't overflow */
          overflow-x: hidden;

          /* Reduce padding on grid containers */
          .max-w-7xl {
            padding-left: 1rem !important;
            padding-right: 1rem !important;
          }

          /* Footer and CTA sections - solid black background */
          footer, [class*="cta"], [class*="get-in-touch"] {
            background-color: black !important;
            background-image: none !important;
          }

          /* Chat widget - black background on mobile */
          [class*="chat"] {
            background-color: black !important;
          }
          }
          `}</style>
      {/* Header */}
      <header 
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled || !isHomePage
            ? 'bg-white/95 backdrop-blur-md shadow-sm' 
            : 'bg-transparent'
        }`}
      >
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 py-3 sm:py-4 h-16 flex items-center">
          <div className="flex items-center justify-between w-full">
            {/* Logo */}
            <Link to={createPageUrl('Home')} className="flex items-center gap-2">
              <img 
                src={isScrolled || !isHomePage 
                  ? "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/85c2c6af0_Untitleddesign-2026-02-05T131703582.png"
                  : "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/b0ab7b77f_Inverse2x.png"
                }
                alt="37Talent - Recruitment and Talent Solutions" 
                className="h-6"
              />
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center gap-8">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  to={createPageUrl(item.page)}
                  className={`font-medium transition-colors ${
                    currentPageName === item.page
                      ? 'text-[#ff0080]'
                      : isScrolled || !isHomePage
                        ? 'text-gray-700 hover:text-[#ff0080]'
                        : 'text-white/90 hover:text-white'
                  }`}
                >
                  {item.name}
                </Link>
              ))}
            </div>

            {/* CTA Buttons */}
            <div className="hidden lg:flex items-center gap-4">
              <Link to={createPageUrl('Jobs')}>
                <Button 
                  variant="ghost"
                  className={`${
                    isScrolled || !isHomePage
                      ? 'text-gray-700 hover:text-[#ff0080] hover:bg-[#ffebf5]'
                      : 'text-white hover:bg-white/10'
                  }`}
                >
                  Find Jobs
                </Button>
              </Link>
              <Link to={createPageUrl('Contact')}>
                <Button className="bg-gradient-to-r from-[#ff0080] to-[#c00060] hover:from-[#c00060] hover:to-[#ff0080] text-white px-6 rounded-xl">
                  Hire Talent
                </Button>
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className={`lg:hidden p-2 rounded-lg ${
                isScrolled || !isHomePage ? 'text-gray-700' : 'text-white'
              }`}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </nav>

        {/* Mobile Menu */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="lg:hidden bg-white border-t"
            >
              <div className="px-6 py-4 space-y-2">
                {navigation.map((item) => (
                  <Link
                    key={item.name}
                    to={createPageUrl(item.page)}
                    className={`block py-3 px-4 rounded-lg font-medium transition-colors ${
                      currentPageName === item.page
                        ? 'bg-[#ffebf5] text-[#ff0080]'
                        : 'text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    {item.name}
                  </Link>
                ))}
                <div className="pt-4 space-y-2">
                  <Link to={createPageUrl('Jobs')}>
                    <Button variant="outline" className="w-full justify-center">
                      Find Jobs
                    </Button>
                  </Link>
                  <Link to={createPageUrl('Contact')}>
                    <Button className="w-full justify-center bg-gradient-to-r from-[#ff0080] to-[#c00060]">
                      Hire Talent
                    </Button>
                  </Link>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Main Content */}
      <main className={`flex-1 ${!isFullScreenHeroPage ? 'pt-20' : ''}`}>
        {children}
      </main>

      {/* Chat Widget */}
      <ChatWidget />

      {/* Footer */}
      <footer className="bg-[#202020] text-white">
        <div className="max-w-7xl mx-auto px-6 py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
            {/* Company Info */}
            <div>
              <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/e823c7141_Inverse2x.png" 
                  alt="37Talent - Recruitment and Talent Solutions" 
                  className="h-6 mb-4"
                />
              <p className="text-gray-400 mb-6 leading-relaxed">
                Powering the technology, media and entertainment industry through innovative talent solutions.
              </p>
              <div className="flex gap-4">
                <a href="https://linkedin.com/company/37talent/?originalSubdomain=au" target="_blank" rel="noopener noreferrer" className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-[#ff0080]/20 transition-colors">
                  <Linkedin className="w-5 h-5" />
                </a>
                <a href="#" className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-[#ff0080]/20 transition-colors">
                  <Twitter className="w-5 h-5" />
                </a>
                <a href="#" className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-[#ff0080]/20 transition-colors">
                  <Facebook className="w-5 h-5" />
                </a>
                <a href="#" className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-[#ff0080]/20 transition-colors">
                  <Instagram className="w-5 h-5" />
                </a>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="font-semibold text-lg mb-4">Quick Links</h4>
              <ul className="space-y-3">
                {navigation.map((item) => (
                  <li key={item.name}>
                    <Link 
                      to={createPageUrl(item.page)}
                      className="text-gray-400 hover:text-cyan-400 transition-colors"
                    >
                      {item.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Services */}
            <div>
              <h4 className="font-semibold text-lg mb-4">Services</h4>
              <ul className="space-y-3">
                <li><a href="#" className="text-gray-400 hover:text-[#ff47a3] transition-colors">Technology Recruitment</a></li>
                <li><a href="#" className="text-gray-400 hover:text-[#ff47a3] transition-colors">Digital Transformation</a></li>
                <li><a href="#" className="text-gray-400 hover:text-[#ff47a3] transition-colors">Government & Public Sector</a></li>
                <li><a href="#" className="text-gray-400 hover:text-[#ff47a3] transition-colors">Executive Search</a></li>
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h4 className="font-semibold text-lg mb-4">Contact Us</h4>
              <ul className="space-y-4">
                <li className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-[#ff47a3] mt-0.5 shrink-0" />
                  <span className="text-gray-400">81-83 Campbell Street, Surry Hills, NSW 2010, Australia</span>
                </li>
                <li className="flex items-center gap-3">
                  <Phone className="w-5 h-5 text-[#ff47a3] shrink-0" />
                  <span className="text-gray-400">+61 2 7241 4413</span>
                </li>
                <li className="flex items-center gap-3">
                  <Mail className="w-5 h-5 text-[#ff47a3] shrink-0" />
                  <span className="text-gray-400">info@37talent.com.au</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="border-t border-white/10 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-500 text-sm">
              © 2024 37Talent. All rights reserved.
            </p>
            <div className="flex gap-6">
              <a href="#" className="text-gray-500 hover:text-gray-400 text-sm">Privacy Policy</a>
              <a href="#" className="text-gray-500 hover:text-gray-400 text-sm">Terms of Service</a>
              <a href="#" className="text-gray-500 hover:text-gray-400 text-sm">Cookie Policy</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
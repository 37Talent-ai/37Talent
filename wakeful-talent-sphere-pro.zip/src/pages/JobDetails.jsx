import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { 
  MapPin, 
  Briefcase, 
  DollarSign, 
  Clock, 
  Share2, 
  Heart,
  ChevronLeft,
  Building2,
  Calendar,
  CheckCircle2,
  Send,
  Bookmark
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

const typeColors = {
  'Permanent': 'bg-emerald-500/10 text-emerald-600 border-emerald-500/30',
  'Contract': 'bg-amber-500/10 text-amber-600 border-amber-500/30',
  'Part-time': 'bg-purple-500/10 text-purple-600 border-purple-500/30',
  'Casual': 'bg-blue-500/10 text-blue-600 border-blue-500/30',
};

function ApplyDialog({ job }) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    coverLetter: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isOpen, setIsOpen] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      await base44.entities.ContactInquiry.create({
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        inquiry_type: 'Job Seeker',
        message: `Application for: ${job.title}\n\n${formData.coverLetter}`,
      });
      
      toast.success('Application submitted successfully!');
      setIsOpen(false);
      setFormData({ name: '', email: '', phone: '', coverLetter: '' });
    } catch (error) {
      toast.error('Failed to submit application. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button className="w-full bg-gradient-to-r from-[#ff0080] to-[#c00060] hover:from-[#c00060] hover:to-[#ff0080] py-6 text-lg rounded-xl">
          Apply Now
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Apply for {job?.title}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div>
            <Label htmlFor="name">Full Name *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
              className="mt-1"
            />
          </div>
          <div>
            <Label htmlFor="email">Email *</Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              required
              className="mt-1"
            />
          </div>
          <div>
            <Label htmlFor="phone">Phone</Label>
            <Input
              id="phone"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className="mt-1"
            />
          </div>
          <div>
            <Label htmlFor="coverLetter">Cover Letter</Label>
            <Textarea
              id="coverLetter"
              value={formData.coverLetter}
              onChange={(e) => setFormData({ ...formData, coverLetter: e.target.value })}
              placeholder="Tell us why you're a great fit for this role..."
              className="mt-1 h-32"
            />
          </div>
          <Button 
            type="submit" 
            className="w-full bg-gradient-to-r from-[#ff0080] to-[#c00060]"
            disabled={isSubmitting}
          >
            {isSubmitting ? 'Submitting...' : 'Submit Application'}
            <Send className="ml-2 w-4 h-4" />
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default function JobDetails() {
  const urlParams = new URLSearchParams(window.location.search);
  const jobId = urlParams.get('id');

  const { data: job, isLoading, error } = useQuery({
    queryKey: ['job', jobId],
    queryFn: async () => {
      const jobs = await base44.entities.Job.filter({ id: jobId });
      return jobs[0];
    },
    enabled: !!jobId,
  });

  const { data: savedJobs } = useQuery({
    queryKey: ['savedJobs'],
    queryFn: () => base44.entities.SavedJob.list(),
    initialData: [],
  });

  const handleSaveJob = async () => {
    const isSaved = savedJobs.some(s => s.job_id === job.id);
    
    if (isSaved) {
      const savedJob = savedJobs.find(s => s.job_id === job.id);
      await base44.entities.SavedJob.delete(savedJob.id);
      toast.success('Job removed from saved');
    } else {
      await base44.entities.SavedJob.create({
        job_id: job.id,
        job_title: job.title,
        job_location: job.location,
        company: job.company,
        saved_at: new Date().toISOString(),
      });
      toast.success('Job saved!');
    }
  };

  const isSaved = savedJobs.some(s => s.job_id === job?.id);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="max-w-4xl mx-auto px-6">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-32 mb-8" />
            <div className="bg-white rounded-2xl p-8">
              <div className="h-8 bg-gray-200 rounded w-3/4 mb-4" />
              <div className="h-6 bg-gray-200 rounded w-1/2 mb-8" />
              <div className="space-y-3">
                <div className="h-4 bg-gray-200 rounded" />
                <div className="h-4 bg-gray-200 rounded" />
                <div className="h-4 bg-gray-200 rounded w-3/4" />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!job) {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h1 className="text-2xl font-semibold text-gray-900 mb-4">Job not found</h1>
          <p className="text-gray-500 mb-6">The job you're looking for doesn't exist or has been removed.</p>
          <Link to={createPageUrl('Jobs')}>
            <Button>Browse All Jobs</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 md:py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        {/* Back Button */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="mb-8"
        >
          <Link 
            to={createPageUrl('Jobs')}
            className="inline-flex items-center text-gray-600 hover:text-gray-900 transition-colors"
          >
            <ChevronLeft className="w-5 h-5 mr-1" />
            Back to Jobs
          </Link>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-6 md:gap-8">
          {/* Main Content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="lg:col-span-2"
          >
            <div className="bg-white rounded-xl sm:rounded-2xl p-6 sm:p-8 shadow-sm border border-gray-100">
              {/* Header */}
              <div className="mb-4 sm:mb-6">
                <div className="flex flex-wrap items-center gap-2 mb-2 sm:mb-3">
                  <Badge className={`${typeColors[job.type]} border font-medium text-xs sm:text-sm`}>
                    {job.type}
                  </Badge>
                  {job.featured && (
                    <Badge className="bg-gradient-to-r from-cyan-500 to-teal-500 text-white border-0 text-xs sm:text-sm">
                      Featured
                    </Badge>
                  )}
                  {job.category && (
                    <Badge variant="outline" className="text-xs sm:text-sm">{job.category}</Badge>
                  )}
                </div>
                <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-gray-900 mb-3 sm:mb-4">
                  {job.title}
                </h1>
                <div className="flex flex-wrap items-center gap-2 sm:gap-4 text-xs sm:text-sm text-gray-500">
                  {job.company && (
                    <span className="flex items-center gap-2">
                      <Building2 className="w-4 h-4" />
                      {job.company}
                    </span>
                  )}
                  <span className="flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    {job.location}, {job.country}
                  </span>
                </div>
              </div>

              <Separator className="my-6" />

              {/* Job Details Grid */}
              <div className="grid sm:grid-cols-2 gap-3 sm:gap-4 mb-6 sm:mb-8">
                {job.salary && (
                  <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl">
                    <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center">
                      <DollarSign className="w-5 h-5 text-emerald-600" />
                    </div>
                    <div>
                      <div className="text-sm text-gray-500">Salary</div>
                      <div className="font-semibold text-gray-900">{job.salary}</div>
                    </div>
                  </div>
                )}
                <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Briefcase className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">Job Type</div>
                    <div className="font-semibold text-gray-900">{job.type}</div>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl">
                  <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                    <MapPin className="w-5 h-5 text-purple-600" />
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">Location</div>
                    <div className="font-semibold text-gray-900">{job.location}</div>
                  </div>
                </div>
                {job.category && (
                  <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl">
                    <div className="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center">
                      <Clock className="w-5 h-5 text-amber-600" />
                    </div>
                    <div>
                      <div className="text-sm text-gray-500">Category</div>
                      <div className="font-semibold text-gray-900">{job.category}</div>
                    </div>
                  </div>
                )}
              </div>

              {/* Description */}
              <div className="mb-8">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Job Description</h2>
                <div className="prose prose-gray max-w-none">
                  <p className="text-gray-600 leading-relaxed whitespace-pre-wrap">
                    {job.description || job.short_description || 'No description provided.'}
                  </p>
                </div>
              </div>

              {/* Requirements */}
              {job.requirements && job.requirements.length > 0 && (
                <div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-4">Requirements</h2>
                  <ul className="space-y-3">
                    {job.requirements.map((req, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <CheckCircle2 className="w-5 h-5 text-[#ff0080] mt-0.5 shrink-0" />
                        <span className="text-gray-600">{req}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </motion.div>

          {/* Sidebar */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="lg:col-span-1"
          >
            <div className="bg-white rounded-xl sm:rounded-2xl p-5 sm:p-6 shadow-sm border border-gray-100 sticky top-20 sm:top-24">
              <ApplyDialog job={job} />
              
              <div className="flex gap-2 mt-3 sm:mt-4">
                <Button 
                  variant="outline" 
                  className="flex-1"
                  onClick={() => {
                    navigator.clipboard.writeText(window.location.href);
                    toast.success('Link copied!');
                  }}
                >
                  <Share2 className="w-4 h-4 mr-2" />
                  Share
                </Button>
                <Button 
                  variant="outline" 
                  className={`flex-1 ${isSaved ? 'bg-[#ffebf5] border-[#ff99cc] text-[#ff0080]' : ''}`}
                  onClick={handleSaveJob}
                >
                  <Bookmark className={`w-4 h-4 mr-2 ${isSaved ? 'fill-current' : ''}`} />
                  {isSaved ? 'Saved' : 'Save'}
                </Button>
              </div>

              <Separator className="my-6" />

              {/* Contact Info */}
              <div className="text-center">
                <p className="text-sm text-gray-500 mb-4">
                  Have questions about this role?
                </p>
                <Link to={createPageUrl('Contact')}>
                  <Button variant="link" className="text-[#ff0080]">
                    Contact our team
                  </Button>
                </Link>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
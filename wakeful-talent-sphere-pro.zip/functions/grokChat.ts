const GROK_API_URL = 'https://api.x.ai/v1/chat/completions';
const GROK_API_KEY = Deno.env.get('GROK_API_KEY');

Deno.serve(async (req) => {
  try {
    const { messages, file_urls } = await req.json();

    if (!messages || !Array.isArray(messages)) {
      return Response.json({ error: 'Invalid messages format' }, { status: 400 });
    }

    // Format messages for Grok API
    const formattedMessages = messages.map(msg => ({
      role: msg.role,
      content: msg.content
    }));

    const response = await fetch(GROK_API_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${GROK_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'grok-4-latest',
        messages: formattedMessages,
        temperature: 0.7,
        max_tokens: 1024,
        ...(file_urls && file_urls.length > 0 && { file_urls }),
      }),
    });

    if (!response.ok) {
      const errorData = await response.text();
      console.error('Grok API error:', errorData);
      return Response.json(
        { error: 'Failed to get response from Grok' },
        { status: response.status }
      );
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;

    if (!content) {
      return Response.json(
        { error: 'No response from Grok' },
        { status: 500 }
      );
    }

    return Response.json({ content });
  } catch (error) {
    console.error('Grok chat error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
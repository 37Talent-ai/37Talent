import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Search, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function HeroSection() {
  const [searchQuery, setSearchQuery] = useState('');
  const [particles, setParticles] = useState([]);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    // Generate floating particles
    const newParticles = Array.from({ length: 50 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 4 + 1,
      duration: Math.random() * 20 + 10,
      delay: Math.random() * 5,
    }));
    setParticles(newParticles);
  }, []);

  useEffect(() => {
    const handleMouseMove = (e) => {
      setMousePosition({
        x: (e.clientX / window.innerWidth) * 20 - 10,
        y: (e.clientY / window.innerHeight) * 20 - 10,
      });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const handleSearch = () => {
    window.location.href = createPageUrl('Jobs') + `?search=${encodeURIComponent(searchQuery)}`;
  };

  return (
    <section className="relative min-h-screen overflow-hidden flex items-center bg-[#04091D]">
      {/* Hero Background Image */}
      <div 
        className="absolute inset-0 bg-top bg-no-repeat"
        style={{
          backgroundImage: 'url(https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/1e603ed76_37Talent6.png)',
          backgroundSize: '120%',
        }}
        role="img"
        aria-label="37Talent hero background - professional recruitment and talent solutions"
      />

      {/* Light Bright Overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#202020]/15 via-[#202020]/5 to-[#202020]/30 sm:block hidden" />

      {/* Animated Background Particles */}
      <div className="absolute inset-0">
        {particles.map((particle) => (
          <motion.div
            key={particle.id}
            className="absolute rounded-full bg-[#ff0080]/30 hidden sm:block"
            style={{
              left: `${particle.x}%`,
              top: `${particle.y}%`,
              width: particle.size,
              height: particle.size,
            }}
            animate={{
              y: [0, -30, 0],
              x: [0, Math.random() * 20 - 10, 0],
              opacity: [0.3, 0.8, 0.3],
              scale: [1, 1.2, 1],
            }}
            transition={{
              duration: particle.duration,
              delay: particle.delay,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
        ))}
      </div>

      {/* 3D Animated Logo Background */}
      <motion.div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] opacity-10"
        style={{
          perspective: '1000px',
          transformStyle: 'preserve-3d',
        }}
        animate={{
          rotateY: 360,
          rotateX: [0, 10, 0, -10, 0],
          z: [0, 50, 0, -50, 0],
        }}
        transition={{
          rotateY: { duration: 20, repeat: Infinity, ease: "linear" },
          rotateX: { duration: 8, repeat: Infinity, ease: "easeInOut" },
          z: { duration: 6, repeat: Infinity, ease: "easeInOut" },
        }}
      >
        <motion.img
          src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/f447e746e_Inverse2x.png"
          alt="37Talent logo - recruitment and talent solutions"
          className="w-full h-full object-contain"
          style={{
            filter: 'drop-shadow(0 0 60px rgba(255, 0, 128, 0.6))',
            transformStyle: 'preserve-3d',
          }}
          animate={{
            scale: [1, 1.1, 1],
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      </motion.div>

      {/* Secondary 3D Logo Layer */}
      <motion.div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] opacity-5"
        style={{
          perspective: '1000px',
          transformStyle: 'preserve-3d',
        }}
        animate={{
          rotateY: -360,
          scale: [1, 1.2, 1],
        }}
        transition={{
          rotateY: { duration: 15, repeat: Infinity, ease: "linear" },
          scale: { duration: 5, repeat: Infinity, ease: "easeInOut" },
        }}
      >
        <img
          src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/f447e746e_Inverse2x.png"
          alt="37Talent logo - recruitment and talent solutions"
          className="w-full h-full object-contain"
          style={{
            filter: 'drop-shadow(0 0 80px rgba(192, 0, 96, 0.8))',
          }}
        />
      </motion.div>

      {/* Gradient Orbs with Parallax */}
      <motion.div 
        className="absolute top-1/4 right-1/4 w-96 h-96 bg-[#ff0080]/20 rounded-full blur-3xl hidden md:block"
        animate={{
          scale: [1, 1.2, 1],
          x: mousePosition.x * 2,
          y: mousePosition.y * 2,
        }}
        transition={{ scale: { duration: 4, repeat: Infinity }, x: { duration: 0.5 }, y: { duration: 0.5 } }}
      />
      <motion.div 
        className="absolute bottom-1/4 left-1/4 w-72 h-72 bg-[#c00060]/20 rounded-full blur-3xl hidden md:block"
        animate={{
          scale: [1, 1.3, 1],
          x: mousePosition.x * -1.5,
          y: mousePosition.y * -1.5,
        }}
        transition={{ scale: { duration: 5, repeat: Infinity }, x: { duration: 0.5 }, y: { duration: 0.5 } }}
      />

      {/* Abstract Shape with Parallax */}
      <motion.div 
        className="absolute right-0 top-1/2 -translate-y-1/2 w-1/2 h-2/3 opacity-60 hidden lg:block"
        initial={{ opacity: 0, scale: 0.8, rotate: 0 }}
        animate={{ 
          opacity: 0.6, 
          scale: 1,
          rotate: 360,
          x: mousePosition.x * -0.5,
          y: mousePosition.y * -0.5,
        }}
        transition={{ 
          opacity: { duration: 1.5 },
          scale: { duration: 1.5 },
          rotate: { duration: 60, repeat: Infinity, ease: "linear" },
          x: { duration: 0.5 },
          y: { duration: 0.5 },
        }}
      >
        <svg viewBox="0 0 400 400" className="w-full h-full">
          <defs>
            <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" style={{ stopColor: '#ff0080', stopOpacity: 0.8 }} />
              <stop offset="100%" style={{ stopColor: '#c00060', stopOpacity: 0.4 }} />
            </linearGradient>
            <filter id="glow">
              <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
              <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
          </defs>
          <motion.path
            d="M200,50 Q350,100 300,200 T200,350 Q50,300 100,200 T200,50"
            fill="none"
            stroke="url(#grad1)"
            strokeWidth="2"
            filter="url(#glow)"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 3, ease: "easeInOut" }}
          />
          {[...Array(20)].map((_, i) => (
            <motion.circle
              key={i}
              cx={200 + Math.cos(i * 0.3) * (80 + i * 5)}
              cy={200 + Math.sin(i * 0.3) * (80 + i * 5)}
              r={2 + Math.random() * 3}
              fill="#ff0080"
              filter="url(#glow)"
              initial={{ opacity: 0 }}
              animate={{ 
                opacity: [0.3, 0.8, 0.3],
                scale: [1, 1.5, 1],
              }}
              transition={{ 
                duration: 2 + Math.random() * 2, 
                repeat: Infinity, 
                delay: i * 0.1 
              }}
            />
          ))}
        </svg>
      </motion.div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12 lg:py-16 pt-[15vh] sm:pt-[20vh] md:pt-12 lg:pt-16">
        <motion.div
          className="max-w-3xl mx-auto text-center"
          style={{
            x: mousePosition.x * 0.5,
            y: mousePosition.y * 0.5,
            textShadow: '0 4px 20px rgba(0, 0, 0, 0.3)',
          }}
        >
          <motion.h1 
            className="text-2xl sm:text-3xl md:text-5xl lg:text-6xl font-bold text-white leading-tight mb-4 sm:mb-6 text-center"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <motion.span
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              We Are{' '}
            </motion.span>
            <motion.span 
              className="text-transparent bg-clip-text bg-gradient-to-r from-[#ff0080] to-[#c00060]"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
              37
            </motion.span>
            <motion.span
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
            >
              Talent
            </motion.span>
            <motion.span 
              className="text-transparent bg-clip-text bg-gradient-to-r from-[#ff0080] to-[#c00060]"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.8 }}
            >
              .
            </motion.span>
          </motion.h1>
          
          <motion.p 
             className="text-sm sm:text-base md:text-lg lg:text-xl text-white mb-6 sm:mb-10 leading-relaxed text-center font-medium"
             initial={{ opacity: 0, y: 20 }}
             animate={{ opacity: 1, y: 0 }}
             transition={{ duration: 0.8, delay: 0.8 }}
           >
            Powering the technology, media and entertainment industry through innovative talent solutions
          </motion.p>

          {/* Search Bar */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1 }}
            className="flex flex-col sm:flex-row gap-3 sm:gap-4 mb-6 sm:mb-8 px-2 sm:px-0"
          >
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                type="text"
                placeholder="Search jobs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                className="w-full pl-10 sm:pl-12 pr-4 py-4 sm:py-6 text-sm sm:text-base bg-white/20 backdrop-blur-md border-white/30 text-white placeholder:text-white/90 rounded-xl focus:border-[#ff0080] focus:ring-[#ff0080]/30"
              />
              </div>
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button 
                onClick={handleSearch}
                className="bg-gradient-to-r from-[#ff0080] to-[#c00060] hover:from-[#c00060] hover:to-[#ff0080] text-white px-6 sm:px-8 py-4 sm:py-6 rounded-xl font-semibold transition-all duration-300 shadow-lg shadow-[#ff0080]/25 hover:shadow-xl hover:shadow-[#ff0080]/40 whitespace-nowrap text-sm sm:text-base"
              >
                Search
              </Button>
              </motion.div>
          </motion.div>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 1.2 }}
            className="flex flex-col sm:flex-row flex-wrap gap-3 sm:gap-4 justify-center px-2 sm:px-0"
          >
            <Link to={createPageUrl('Jobs')} className="w-full sm:w-auto">
              <motion.div whileHover={{ scale: 1.05, x: 5 }} whileTap={{ scale: 0.95 }} className="w-full">
                <Button 
                  variant="outline" 
                  className="border-2 border-white text-white hover:bg-white hover:text-[#c00060] px-4 sm:px-6 py-4 sm:py-5 rounded-xl group backdrop-blur-md bg-white/15 w-full text-sm sm:text-base"
                >
                  Browse All Jobs
                  <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Button>
              </motion.div>
            </Link>
            <Link to={createPageUrl('Contact')} className="w-full sm:w-auto">
              <motion.div whileHover={{ scale: 1.05, x: 5 }} whileTap={{ scale: 0.95 }} className="w-full">
                <Button 
                  className="bg-white/25 backdrop-blur-md border-2 border-white text-white hover:bg-white hover:text-[#c00060] px-4 sm:px-6 py-4 sm:px-5 rounded-xl font-semibold shadow-lg w-full text-sm sm:text-base"
                >
                  Hire Top Talent
                </Button>
              </motion.div>
            </Link>
          </motion.div>
        </motion.div>
      </div>


    </section>
  );
}
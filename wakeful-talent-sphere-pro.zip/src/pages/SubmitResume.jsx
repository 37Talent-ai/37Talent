import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useMutation } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Upload, CheckCircle2, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { toast } from 'sonner';

export default function SubmitResume() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    position: '',
    resume_url: '',
    cover_letter: '',
  });
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isUploading, setIsUploading] = useState(false);

  const mutation = useMutation({
    mutationFn: (data) => base44.entities.Resume.create(data),
    onSuccess: () => {
      setIsSubmitted(true);
      setFormData({
        name: '',
        email: '',
        phone: '',
        position: '',
        resume_url: '',
        cover_letter: '',
      });
    },
    onError: () => {
      toast.error('Failed to submit resume. Please try again.');
    },
  });

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData({ ...formData, resume_url: file_url });
      toast.success('Resume uploaded successfully');
    } catch (error) {
      toast.error('Failed to upload resume');
    } finally {
      setIsUploading(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.resume_url) {
      toast.error('Please upload a resume');
      return;
    }
    mutation.mutate(formData);
  };

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <div className="bg-gradient-to-br from-[#202020] via-[#c00060] to-[#202020] py-16 md:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl"
          >
            <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4 sm:mb-6">
              Submit Your Resume
            </h1>
            <p className="text-sm sm:text-base md:text-lg lg:text-xl text-gray-400 leading-relaxed">
              We'd love to review your profile. Submit your resume and let's 
              explore opportunities that match your skills.
            </p>
          </motion.div>
        </div>
      </div>

      {/* Form Section */}
      <section className="py-16 md:py-20 bg-gray-50">
        <div className="max-w-2xl mx-auto px-4 sm:px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl sm:rounded-3xl p-6 sm:p-8 shadow-sm border border-gray-100"
          >
            {isSubmitted ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center py-12"
              >
                <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <CheckCircle2 className="w-8 h-8 text-emerald-500" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">
                  Resume Received!
                </h3>
                <p className="text-gray-600 mb-8">
                  Thank you for submitting your resume. We'll review it and 
                  get back to you soon if there's a great fit.
                </p>
                <Link to={createPageUrl('Jobs')}>
                  <Button className="bg-gradient-to-r from-[#ff0080] to-[#c00060]">
                    Browse More Jobs
                  </Button>
                </Link>
              </motion.div>
            ) : (
              <>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Full Name *</Label>
                      <Input
                        id="name"
                        value={formData.name}
                        onChange={(e) =>
                          setFormData({ ...formData, name: e.target.value })
                        }
                        required
                        className="mt-1"
                        placeholder="John Doe"
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">Email *</Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) =>
                          setFormData({ ...formData, email: e.target.value })
                        }
                        required
                        className="mt-1"
                        placeholder="john@example.com"
                      />
                    </div>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="phone">Phone</Label>
                      <Input
                        id="phone"
                        value={formData.phone}
                        onChange={(e) =>
                          setFormData({ ...formData, phone: e.target.value })
                        }
                        className="mt-1"
                        placeholder="+61 400 000 000"
                      />
                    </div>
                    <div>
                      <Label htmlFor="position">Position Interested In</Label>
                      <Input
                        id="position"
                        value={formData.position}
                        onChange={(e) =>
                          setFormData({ ...formData, position: e.target.value })
                        }
                        className="mt-1"
                        placeholder="e.g., Software Engineer"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="resume">Upload Resume *</Label>
                    <div className="mt-2 border-2 border-dashed border-gray-300 rounded-xl p-6 text-center hover:border-[#ff0080] transition-colors">
                      <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                      <input
                        id="resume"
                        type="file"
                        onChange={handleFileUpload}
                        disabled={isUploading}
                        className="hidden"
                        accept=".pdf,.doc,.docx"
                      />
                      <label htmlFor="resume" className="cursor-pointer">
                        <span className="text-sm text-gray-600">
                          {formData.resume_url
                            ? '✓ Resume uploaded'
                            : isUploading
                            ? 'Uploading...'
                            : 'Click to upload or drag and drop'}
                        </span>
                        <span className="text-xs text-gray-400 block">
                          PDF, DOC, or DOCX
                        </span>
                      </label>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="cover_letter">Cover Letter (Optional)</Label>
                    <Textarea
                      id="cover_letter"
                      value={formData.cover_letter}
                      onChange={(e) =>
                        setFormData({ ...formData, cover_letter: e.target.value })
                      }
                      className="mt-1 h-28"
                      placeholder="Tell us about yourself..."
                    />
                  </div>

                  <div className="flex gap-4">
                    <Link to={createPageUrl('Jobs')} className="flex-1">
                      <Button
                        type="button"
                        variant="outline"
                        className="w-full"
                      >
                        <ArrowLeft className="mr-2 w-4 h-4" />
                        Back to Jobs
                      </Button>
                    </Link>
                    <Button
                      type="submit"
                      className="flex-1 bg-gradient-to-r from-[#ff0080] to-[#c00060] hover:from-[#c00060] hover:to-[#ff0080]"
                      disabled={mutation.isPending}
                    >
                      {mutation.isPending ? 'Submitting...' : 'Submit Resume'}
                    </Button>
                  </div>
                </form>
              </>
            )}
          </motion.div>
        </div>
      </section>
    </div>
  );
}
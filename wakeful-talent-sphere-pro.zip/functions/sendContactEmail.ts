import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    
    const { data: contactInquiry } = body;
    
    if (!contactInquiry) {
      return Response.json({ error: 'Missing inquiry data' }, { status: 400 });
    }

    // Get Gmail access token
    const accessToken = await base44.asServiceRole.connectors.getAccessToken('gmail');

    // Get the authenticated user's email
    const profileResponse = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/profile', {
      headers: { 'Authorization': `Bearer ${accessToken}` }
    });
    const profile = await profileResponse.json();
    const userEmail = profile.emailAddress;

    let emailContent;

    if (contactInquiry.attachment_url) {
      // Fetch the attachment file
      const fileResponse = await fetch(contactInquiry.attachment_url);
      const arrayBuffer = await fileResponse.arrayBuffer();

      // Convert to base64 in chunks to avoid string length limits
      const uint8Array = new Uint8Array(arrayBuffer);
      const chunkSize = 0x8000;
      let fileBase64 = '';
      for (let i = 0; i < uint8Array.length; i += chunkSize) {
        fileBase64 += String.fromCharCode.apply(null, uint8Array.subarray(i, i + chunkSize));
      }
      fileBase64 = btoa(fileBase64);

      // Get filename from URL and content type
      const urlParts = contactInquiry.attachment_url.split('/');
      const fileName = decodeURIComponent(urlParts[urlParts.length - 1].split('_').slice(1).join('_') || 'resume.pdf');
      const contentType = fileResponse.headers.get('content-type') || 'application/pdf';

      // Create multipart email with attachment
      const boundary = '----=_Part_' + Date.now();
      const messageParts = [];

      // Headers
      messageParts.push(`To: ${userEmail}`);
      messageParts.push(`Subject: New ${contactInquiry.inquiry_type} Inquiry from ${contactInquiry.name}`);
      messageParts.push(`Reply-To: ${contactInquiry.email}`);
      messageParts.push('MIME-Version: 1.0');
      messageParts.push(`Content-Type: multipart/mixed; boundary="${boundary}"`);
      messageParts.push('');

      // HTML body part
      messageParts.push(`--${boundary}`);
      messageParts.push('Content-Type: text/html; charset=utf-8');
      messageParts.push('Content-Transfer-Encoding: quoted-printable');
      messageParts.push('');
      messageParts.push(`<h2>New Contact Form Submission</h2>`);
      messageParts.push(`<p><strong>Name:</strong> ${contactInquiry.name}</p>`);
      messageParts.push(`<p><strong>Email:</strong> ${contactInquiry.email}</p>`);
      messageParts.push(`<p><strong>Phone:</strong> ${contactInquiry.phone || 'Not provided'}</p>`);
      messageParts.push(`<p><strong>Inquiry Type:</strong> ${contactInquiry.inquiry_type}</p>`);
      messageParts.push(`<p><strong>Message:</strong></p>`);
      messageParts.push(`<p>${contactInquiry.message.replace(/\n/g, '<br>')}</p>`);
      messageParts.push(`<hr>`);
      messageParts.push(`<p><small>Submitted on: ${new Date(contactInquiry.created_date).toLocaleString()}</small></p>`);
      messageParts.push('');

      // Attachment part
      messageParts.push(`--${boundary}`);
      messageParts.push(`Content-Type: ${contentType}; name="${fileName}"`);
      messageParts.push(`Content-Disposition: attachment; filename="${fileName}"`);
      messageParts.push('Content-Transfer-Encoding: base64');
      messageParts.push('');
      // Split base64 into 76-character lines as per RFC
      const base64Lines = fileBase64.match(/.{1,76}/g) || [];
      messageParts.push(base64Lines.join('\n'));
      messageParts.push('');
      messageParts.push(`--${boundary}--`);

      emailContent = messageParts.join('\r\n');
    } else {
      // Simple HTML email without attachment
      emailContent = [
        'Content-Type: text/html; charset=utf-8',
        'MIME-Version: 1.0',
        `To: ${userEmail}`,
        `Subject: New ${contactInquiry.inquiry_type} Inquiry from ${contactInquiry.name}`,
        `Reply-To: ${contactInquiry.email}`,
        '',
        `<h2>New Contact Form Submission</h2>`,
        `<p><strong>Name:</strong> ${contactInquiry.name}</p>`,
        `<p><strong>Email:</strong> ${contactInquiry.email}</p>`,
        `<p><strong>Phone:</strong> ${contactInquiry.phone || 'Not provided'}</p>`,
        `<p><strong>Inquiry Type:</strong> ${contactInquiry.inquiry_type}</p>`,
        `<p><strong>Message:</strong></p>`,
        `<p>${contactInquiry.message.replace(/\n/g, '<br>')}</p>`,
        `<hr>`,
        `<p><small>Submitted on: ${new Date(contactInquiry.created_date).toLocaleString()}</small></p>`
      ].join('\r\n');
    }

    // Base64url encode the email
    const encodedEmail = btoa(emailContent)
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=+$/, '');

    // Send via Gmail API
    const response = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        raw: encodedEmail
      })
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Gmail API error: ${error}`);
    }

    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});
import React from 'react';

export default function Logo({ isDark = false }) {
  return (
    <div className="flex items-center">
      <span className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-[#ff0080]'}`}>
        37
      </span>
      <span className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-black'}`}>
        Talent
      </span>
      <span className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-[#ff0080]'}`}>
        .
      </span>
    </div>
  );
}
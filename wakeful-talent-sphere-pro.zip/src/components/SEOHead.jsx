import { useEffect } from 'react';

export default function SEOHead({ 
  title = '37Talent | Recruitment & Talent Solutions | Sydney, Australia',
  description = '37Talent delivers expert recruitment, talent advisory, and executive search services across Australia. Trusted by leading organisations for top talent solutions. Contact us today.',
  canonical = 'https://37talent.com.au/',
  ogTitle,
  ogDescription,
  ogImage = 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/b0ab7b77f_Inverse2x.png',
  ogUrl,
  ogType = 'website',
  twitterCard = 'summary_large_image'
}) {
  useEffect(() => {
    // Title
    document.title = title;

    // Meta tags
    const updateOrCreateMeta = (name, content, isProperty = false) => {
      const attr = isProperty ? 'property' : 'name';
      let element = document.querySelector(`meta[${attr}="${name}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute(attr, name);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    updateOrCreateMeta('description', description);
    updateOrCreateMeta('robots', 'index, follow');
    updateOrCreateMeta('og:title', ogTitle || title, true);
    updateOrCreateMeta('og:description', ogDescription || description, true);
    updateOrCreateMeta('og:image', ogImage, true);
    updateOrCreateMeta('og:url', ogUrl || canonical, true);
    updateOrCreateMeta('og:type', ogType, true);
    updateOrCreateMeta('twitter:card', twitterCard);

    // Canonical
    let canonicalLink = document.querySelector('link[rel="canonical"]');
    if (!canonicalLink) {
      canonicalLink = document.createElement('link');
      canonicalLink.rel = 'canonical';
      document.head.appendChild(canonicalLink);
    }
    canonicalLink.href = canonical;

    return () => {
      // Cleanup if needed
    };
  }, [title, description, canonical, ogTitle, ogDescription, ogImage, ogUrl, ogType, twitterCard]);

  return null;
}
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { job_title, required_skills, company_info, location, job_type } = await req.json();

    if (!job_title || !required_skills || !company_info) {
      return Response.json(
        { error: 'Missing required fields: job_title, required_skills, company_info' },
        { status: 400 }
      );
    }

    const prompt = `Create a compelling and detailed job description for the following position:

Job Title: ${job_title}
Company: ${company_info}
Location: ${location || 'Not specified'}
Employment Type: ${job_type || 'Not specified'}
Required Skills: ${Array.isArray(required_skills) ? required_skills.join(', ') : required_skills}

Generate a professional job description that:
1. Starts with an engaging overview of the role
2. Clearly outlines key responsibilities
3. Lists required qualifications and skills
4. Mentions nice-to-have skills
5. Describes the ideal candidate profile
6. Is compelling and encourages qualified candidates to apply

Format the response as a well-structured, professional job description suitable for posting on a careers page.`;

    const response = await base44.integrations.Core.InvokeLLM({
      prompt: prompt,
      add_context_from_internet: false,
    });

    return Response.json({
      description: response,
      success: true
    });
  } catch (error) {
    console.error('Error generating job description:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
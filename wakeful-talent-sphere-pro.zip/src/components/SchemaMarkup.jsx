import { useEffect } from 'react';

export default function SchemaMarkup() {
  useEffect(() => {
    // Organization & LocalBusiness Schema
    const organizationSchema = {
      '@context': 'https://schema.org',
      '@type': 'Organization',
      'name': '37Talent',
      'url': 'https://37talent.com.au/',
      'logo': 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/b0ab7b77f_Inverse2x.png',
      'description': '37Talent delivers expert recruitment, talent advisory, and executive search services across Australia.',
      'address': {
        '@type': 'PostalAddress',
        'streetAddress': '81-83 Campbell Street',
        'addressLocality': 'Surry Hills',
        'addressRegion': 'NSW',
        'postalCode': '2010',
        'addressCountry': 'AU'
      },
      'contactPoint': {
        '@type': 'ContactPoint',
        'telephone': '+61-2-7241-4413',
        'contactType': 'customer service',
        'email': 'info@37talent.com.au'
      },
      'sameAs': [
        'https://linkedin.com/company/37talent/?originalSubdomain=au'
      ]
    };

    // Service Schemas
    const services = [
      {
        name: 'Technology Recruitment',
        description: 'Expert recruitment services for technology professionals and leadership roles.'
      },
      {
        name: 'Digital Transformation',
        description: 'Talent solutions for digital transformation initiatives across industries.'
      },
      {
        name: 'Government & Public Sector',
        description: 'Specialized recruitment for government and public sector organisations.'
      },
      {
        name: 'Executive Search',
        description: 'Executive search and senior leadership recruitment services.'
      }
    ];

    const serviceSchemas = services.map(service => ({
      '@context': 'https://schema.org',
      '@type': 'Service',
      'name': service.name,
      'description': service.description,
      'provider': {
        '@type': 'Organization',
        'name': '37Talent',
        'url': 'https://37talent.com.au/'
      },
      'areaServed': {
        '@type': 'Country',
        'name': 'AU'
      }
    }));

    // Add Organization schema
    const orgScript = document.createElement('script');
    orgScript.type = 'application/ld+json';
    orgScript.innerHTML = JSON.stringify(organizationSchema);
    orgScript.id = 'org-schema';
    document.head.appendChild(orgScript);

    // Add Service schemas
    serviceSchemas.forEach((schema, index) => {
      const serviceScript = document.createElement('script');
      serviceScript.type = 'application/ld+json';
      serviceScript.innerHTML = JSON.stringify(schema);
      serviceScript.id = `service-schema-${index}`;
      document.head.appendChild(serviceScript);
    });

    return () => {
      const orgScriptEl = document.getElementById('org-schema');
      if (orgScriptEl) orgScriptEl.remove();
      serviceSchemas.forEach((_, index) => {
        const el = document.getElementById(`service-schema-${index}`);
        if (el) el.remove();
      });
    };
  }, []);

  return null;
}
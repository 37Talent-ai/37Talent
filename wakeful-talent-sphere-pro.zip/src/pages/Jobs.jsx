import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { 
        Search, 
        MapPin, 
        Filter, 
        X,
        Briefcase,
        DollarSign,
        ChevronDown,
        ArrowRight,
        SlidersHorizontal,
        Bookmark
      } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const typeColors = {
  'Permanent': 'bg-emerald-500/10 text-emerald-600 border-emerald-500/30',
  'Contract': 'bg-amber-500/10 text-amber-600 border-amber-500/30',
  'Part-time': 'bg-purple-500/10 text-purple-600 border-purple-500/30',
  'Casual': 'bg-blue-500/10 text-blue-600 border-blue-500/30',
};

const categories = ['All', 'Media and Entertainment', 'Technology', 'Retail Media', 'SaaS', 'Transformation', 'Other'];
const jobTypes = ['All', 'Permanent', 'Contract', 'Part-time', 'Casual'];
const locations = ['All', 'Sydney', 'Melbourne', 'Brisbane', 'Perth', 'Auckland', 'Wellington'];

function JobCard({ job, isSaved, onSave }) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="group"
    >
      <div className="bg-white rounded-2xl p-6 border border-gray-100 hover:border-[#ff99cc] hover:shadow-lg transition-all duration-300">
        <div className="flex flex-col lg:flex-row lg:items-center gap-4 relative">
          {/* Main Info */}
          <div className="flex-1">
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <Badge className={`${typeColors[job.type]} border font-medium`}>
                {job.type}
              </Badge>
              {job.featured && (
                <Badge className="bg-gradient-to-r from-cyan-500 to-teal-500 text-white border-0">
                  Featured
                </Badge>
              )}
              {job.category && (
                <Badge variant="outline" className="text-gray-500">
                  {job.category}
                </Badge>
              )}
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2 group-hover:text-[#ff0080] transition-colors">
              {job.title}
            </h3>
            <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500">
              {job.company && (
                <span className="flex items-center gap-1">
                  <Briefcase className="w-4 h-4" />
                  {job.company}
                </span>
              )}
              <span className="flex items-center gap-1">
                <MapPin className="w-4 h-4" />
                {job.location}, {job.country}
              </span>
              {job.salary && (
                <span className="flex items-center gap-1">
                  <DollarSign className="w-4 h-4" />
                  {job.salary}
                </span>
              )}
            </div>
          </div>

          {/* Description & CTA */}
          <div className="lg:w-1/3 lg:text-right space-y-3">
            <p className="text-gray-500 text-sm line-clamp-2 lg:hidden">
              {job.short_description || job.description}
            </p>
            <div className="flex flex-col gap-2">
              <Link to={createPageUrl('JobDetails') + `?id=${job.id}`}>
                <Button 
                  variant="outline" 
                  className="w-full lg:w-auto border-[#ff99cc] text-[#ff0080] hover:bg-[#ffebf5] group/btn"
                >
                  View Details
                  <ArrowRight className="ml-2 w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                </Button>
              </Link>
              <button
                onClick={onSave}
                className={`flex items-center justify-center lg:justify-start gap-2 px-4 py-2 rounded-lg transition-colors ${
                  isSaved
                    ? 'bg-[#ffebf5] text-[#ff0080]'
                    : 'border border-gray-200 text-gray-600 hover:border-[#ff99cc] hover:text-[#ff0080]'
                }`}
              >
                <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
                <span className="text-sm font-medium">{isSaved ? 'Saved' : 'Save'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function FilterSection({ filters, setFilters, onClear }) {
  return (
    <div className="space-y-6">
      {/* Category */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
        <Select 
          value={filters.category} 
          onValueChange={(value) => setFilters({ ...filters, category: value })}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select category" />
          </SelectTrigger>
          <SelectContent>
            {categories.map((cat) => (
              <SelectItem key={cat} value={cat}>{cat}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Job Type */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Job Type</label>
        <Select 
          value={filters.type} 
          onValueChange={(value) => setFilters({ ...filters, type: value })}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select type" />
          </SelectTrigger>
          <SelectContent>
            {jobTypes.map((type) => (
              <SelectItem key={type} value={type}>{type}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Location */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
        <Select 
          value={filters.location} 
          onValueChange={(value) => setFilters({ ...filters, location: value })}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select location" />
          </SelectTrigger>
          <SelectContent>
            {locations.map((loc) => (
              <SelectItem key={loc} value={loc}>{loc}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <Button 
        variant="outline" 
        className="w-full"
        onClick={onClear}
      >
        Clear Filters
      </Button>
    </div>
  );
}

export default function Jobs() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    category: 'All',
    type: 'All',
    location: 'All',
  });

  // Get search from URL
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const search = params.get('search');
    if (search) setSearchQuery(search);
  }, []);

  const { data: jobs, isLoading } = useQuery({
    queryKey: ['jobs'],
    queryFn: () => base44.entities.Job.list('-created_date'),
    initialData: [],
  });

  const { data: savedJobs } = useQuery({
    queryKey: ['savedJobs'],
    queryFn: () => base44.entities.SavedJob.list(),
    initialData: [],
  });

  const filteredJobs = jobs.filter((job) => {
    const matchesSearch = !searchQuery || 
      job.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.company?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.location?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = filters.category === 'All' || job.category === filters.category;
    const matchesType = filters.type === 'All' || job.type === filters.type;
    const matchesLocation = filters.location === 'All' || job.location?.includes(filters.location);

    return matchesSearch && matchesCategory && matchesType && matchesLocation;
  });

  const activeFiltersCount = Object.values(filters).filter(v => v !== 'All').length;

  const clearFilters = () => {
    setFilters({
      category: 'All',
      type: 'All',
      location: 'All',
    });
  };

  const handleSaveJob = async (job) => {
    const isSaved = savedJobs.some(s => s.job_id === job.id);

    if (isSaved) {
      const savedJob = savedJobs.find(s => s.job_id === job.id);
      await base44.entities.SavedJob.delete(savedJob.id);
    } else {
      await base44.entities.SavedJob.create({
        job_id: job.id,
        job_title: job.title,
        job_location: job.location,
        company: job.company,
        saved_at: new Date().toISOString(),
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero */}
      <div className="relative min-h-screen overflow-hidden flex items-center">
        <div 
          className="absolute inset-0 bg-top bg-no-repeat"
          style={{ 
            backgroundImage: 'url(https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/604e6e1de_PortraitsofGroupofPeopleonMulticoloredBackgroundinNeon.jpg)',
            backgroundSize: '120%',
          }}
        />
        <div className="absolute inset-0 bg-black/40" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <h1 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl xl:text-5xl font-bold text-white mb-3 sm:mb-4">
              Find Your Perfect Role
            </h1>
            <p className="text-xs sm:text-sm md:text-base lg:text-lg text-gray-400 mb-6 sm:mb-8 max-w-2xl mx-auto">
              Browse {jobs.length}+ opportunities across technology, digital transformation, and beyond.
            </p>

            {/* Search Bar */}
            <div className="max-w-2xl mx-auto relative mb-4">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                type="text"
                placeholder="Search by title, skill, or company..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-6 bg-white rounded-xl text-gray-900 placeholder:text-gray-400"
              />
            </div>
            <div className="max-w-2xl mx-auto">
              <Link to={createPageUrl('SubmitResume')}>
                <Button variant="outline" className="border-white/30 text-white hover:bg-white/10 w-full">
                  Submit Your Resume
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Career Elevation Section */}
      <section className="bg-white py-8 md:py-10">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Elevate Your Career to New Levels
            </h2>
            <div className="space-y-4 text-gray-600 text-base md:text-lg leading-relaxed mb-8">
              <p>
                No matter how ambitious your goals, we turn them into reality. Our expert consultants bring deep industry insight and a proven track record to guide you to your ideal role, handling every step of the process with precision and care.
              </p>
              <p>
                We partner with iconic global brands, cutting-edge SaaS companies, innovative ad tech firms, and high-growth startups.
              </p>
              <p className="font-semibold text-gray-900">
                Ready to take the next step? <Link to={createPageUrl('Contact')} className="text-[#FF0080] hover:underline">Let's make your career move unstoppable.</Link>
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 pt-4 pb-12">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Desktop Filters */}
          <div className="hidden lg:block w-64 shrink-0">
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 sticky top-24">
              <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <Filter className="w-4 h-4" />
                Filters
              </h3>
              <FilterSection 
                filters={filters} 
                setFilters={setFilters} 
                onClear={clearFilters}
              />
            </div>
          </div>

          {/* Jobs List */}
          <div className="flex-1">
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <p className="text-gray-600">
                Showing <span className="font-semibold text-gray-900">{filteredJobs.length}</span> jobs
              </p>
              
              {/* Mobile Filter Button */}
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="outline" className="lg:hidden">
                    <SlidersHorizontal className="w-4 h-4 mr-2" />
                    Filters
                    {activeFiltersCount > 0 && (
                      <Badge className="ml-2 bg-[#ff0080] text-white">{activeFiltersCount}</Badge>
                    )}
                  </Button>
                </SheetTrigger>
                <SheetContent>
                  <SheetHeader>
                    <SheetTitle>Filter Jobs</SheetTitle>
                  </SheetHeader>
                  <div className="mt-6">
                    <FilterSection 
                      filters={filters} 
                      setFilters={setFilters} 
                      onClear={clearFilters}
                    />
                  </div>
                </SheetContent>
              </Sheet>
            </div>

            {/* Active Filters */}
            {activeFiltersCount > 0 && (
              <div className="flex flex-wrap gap-2 mb-6">
                {Object.entries(filters).map(([key, value]) => 
                  value !== 'All' && (
                    <Badge 
                      key={key} 
                      variant="secondary" 
                      className="px-3 py-1 bg-[#ffebf5] text-[#ff0080]"
                    >
                      {value}
                      <button 
                        onClick={() => setFilters({ ...filters, [key]: 'All' })}
                        className="ml-2 hover:text-[#c00060]"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  )
                )}
                <button 
                  onClick={clearFilters}
                  className="text-sm text-gray-500 hover:text-gray-700"
                >
                  Clear all
                </button>
              </div>
            )}

            {/* Jobs */}
            {isLoading ? (
              <div className="space-y-4">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="bg-white rounded-2xl p-6 animate-pulse">
                    <div className="flex items-center gap-2 mb-3">
                      <div className="h-6 w-20 bg-gray-200 rounded-full" />
                      <div className="h-6 w-24 bg-gray-200 rounded-full" />
                    </div>
                    <div className="h-6 w-3/4 bg-gray-200 rounded mb-2" />
                    <div className="h-4 w-1/2 bg-gray-200 rounded" />
                  </div>
                ))}
              </div>
            ) : filteredJobs.length > 0 ? (
              <motion.div layout className="space-y-4">
                <AnimatePresence>
                  {filteredJobs.map((job) => (
                    <JobCard 
                      key={job.id} 
                      job={job}
                      isSaved={savedJobs.some(s => s.job_id === job.id)}
                      onSave={() => handleSaveJob(job)}
                    />
                  ))}
                </AnimatePresence>
              </motion.div>
            ) : (
              <div className="bg-white rounded-2xl p-12 text-center">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Search className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">No jobs found</h3>
                <p className="text-gray-500 mb-4">
                  Try adjusting your search or filters to find what you're looking for.
                </p>
                <Button onClick={clearFilters} variant="outline">
                  Clear Filters
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
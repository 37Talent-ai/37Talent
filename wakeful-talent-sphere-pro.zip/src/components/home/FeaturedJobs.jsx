import React from 'react';
import { motion } from 'framer-motion';
import { MapPin, Clock, DollarSign, ArrowRight, Briefcase } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const typeColors = {
  'Permanent': 'bg-[#c00060]/10 text-[#c00060] border-[#c00060]/30',
  'Contract': 'bg-[#ff47a3]/10 text-[#c00060] border-[#ff47a3]/30',
  'Part-time': 'bg-[#ff99cc]/10 text-[#ff0080] border-[#ff99cc]/30',
  'Casual': 'bg-[#ff0080]/10 text-[#c00060] border-[#ff0080]/30',
};

function JobCard({ job, index }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="group"
    >
      <div className="relative bg-white rounded-2xl p-6 shadow-sm border border-gray-100 hover:shadow-xl hover:border-cyan-200 transition-all duration-300 h-full flex flex-col">
        {/* Job Type Badge */}
        <div className="flex items-start justify-between mb-4">
          <Badge className={`${typeColors[job.type]} border font-medium`}>
            {job.type}
          </Badge>
          {job.featured && (
            <Badge className="bg-gradient-to-r from-[#ff0080] to-[#c00060] text-white border-0">
              Featured
            </Badge>
          )}
        </div>

        {/* Job Title */}
        <h3 className="text-lg font-semibold text-gray-900 mb-3 group-hover:text-[#ff0080] transition-colors line-clamp-2">
          {job.title}
        </h3>

        {/* Job Details */}
        <div className="space-y-2 mb-4 flex-1">
          {job.company && (
            <div className="flex items-center gap-2 text-gray-600">
              <Briefcase className="w-4 h-4 text-gray-400" />
              <span className="text-sm">{job.company}</span>
            </div>
          )}
          <div className="flex items-center gap-2 text-gray-600">
            <MapPin className="w-4 h-4 text-gray-400" />
            <span className="text-sm">{job.location}, {job.country}</span>
          </div>
          {job.salary && (
            <div className="flex items-center gap-2 text-gray-600">
              <DollarSign className="w-4 h-4 text-gray-400" />
              <span className="text-sm">{job.salary}</span>
            </div>
          )}
        </div>

        {/* Description */}
        <p className="text-gray-500 text-sm mb-4 line-clamp-3">
          {job.short_description || job.description}
        </p>

        {/* Apply Button */}
        <Link to={createPageUrl('JobDetails') + `?id=${job.id}`}>
          <Button 
            variant="ghost" 
            className="w-full justify-between text-[#ff0080] hover:text-[#c00060] hover:bg-[#ffebf5] group/btn"
          >
            View Details
            <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </div>
    </motion.div>
  );
}

export default function FeaturedJobs({ jobs, isLoading }) {
  const featuredJobs = jobs?.filter(j => j.featured).slice(0, 6) || [];
  const displayJobs = featuredJobs.length > 0 ? featuredJobs : jobs?.slice(0, 6) || [];

  if (isLoading) {
    return (
      <section className="py-20 relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #062D32 0%, #0a3f47 50%, #062D32 100%)' }}>
        {/* Animated Background Orbs */}
        <motion.div 
          className="absolute top-1/4 -right-1/2 w-96 h-96 bg-[#ff0080]/5 rounded-full blur-3xl"
          animate={{
            scale: [1, 1.2, 1],
            x: [0, 30, 0],
          }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div 
          className="absolute -bottom-1/2 -left-1/4 w-80 h-80 bg-[#c00060]/5 rounded-full blur-3xl"
          animate={{
            scale: [1.2, 1, 1.2],
            y: [0, -30, 0],
          }}
          transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
        />
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="text-center mb-12">
            <div className="h-10 bg-gray-200 rounded w-64 mx-auto mb-4 animate-pulse" />
            <div className="h-6 bg-gray-200 rounded w-96 mx-auto animate-pulse" />
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-white rounded-2xl p-6 shadow-sm animate-pulse">
                <div className="h-6 bg-gray-200 rounded w-20 mb-4" />
                <div className="h-6 bg-gray-200 rounded w-3/4 mb-3" />
                <div className="space-y-2 mb-4">
                  <div className="h-4 bg-gray-200 rounded w-1/2" />
                  <div className="h-4 bg-gray-200 rounded w-2/3" />
                </div>
                <div className="h-16 bg-gray-200 rounded mb-4" />
                <div className="h-10 bg-gray-200 rounded" />
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-20" style={{ backgroundColor: '#062D32' }}>
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Featured Jobs.
          </h2>
          <p className="text-gray-300 text-lg max-w-2xl mx-auto">
            Discover exciting opportunities across technology, digital transformation, and beyond.
          </p>
        </motion.div>

        {/* Jobs Grid */}
        {displayJobs.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {displayJobs.map((job, index) => (
              <JobCard key={job.id} job={job} index={index} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12 text-gray-500">
            No jobs available at the moment. Check back soon!
          </div>
        )}

        {/* View All Button */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <Link to={createPageUrl('Jobs')}>
            <Button className="bg-gradient-to-r from-[#ff0080] to-[#c00060] hover:from-[#c00060] hover:to-[#ff0080] text-white px-8 py-6 rounded-xl font-semibold shadow-lg shadow-[#ff0080]/25">
              View All Jobs
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
        </motion.div>
      </div>
    </section>
  );
}
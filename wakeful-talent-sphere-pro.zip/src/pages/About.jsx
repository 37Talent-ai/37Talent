import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Target, 
  Heart, 
  Users, 
  Award,
  Globe,
  TrendingUp,
  ArrowRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const values = [
  {
    icon: Target,
    title: 'Excellence',
    description: 'We strive for excellence in everything we do, delivering results that exceed expectations.',
  },
  {
    icon: Heart,
    title: 'Integrity',
    description: 'We build trust through honesty, transparency, and ethical business practices.',
  },
  {
    icon: Users,
    title: 'Partnership',
    description: 'We view every relationship as a partnership, working collaboratively toward shared success.',
  },
  {
    icon: Award,
    title: 'Innovation',
    description: 'We embrace new ideas and technologies to stay ahead in a rapidly evolving industry.',
  },
];

const milestones = [
  { year: '2021', title: 'Founded', description: 'Started with a vision to transform recruitment' },
  { year: '2022', title: 'Building Momentum', description: 'Established partnerships with leading organisations' },
  { year: '2023', title: 'Global Expansion', description: 'Expanded across ANZ, APAC and US markets' },
  { year: '2024', title: 'Digital Innovation', description: 'Integrated cutting-edge recruitment technology' },
  { year: '2025', title: 'Industry Recognition', description: 'Recognised as a leading digital talent partner' },
];

const team = [
  {
    name: 'Nick Squires',
    role: 'Founder',
    image: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/cfc837a96_1723245445163.jpeg',
  },
  {
    name: 'Ashling McGwynne',
    role: 'Digital Talent Manager',
    image: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/938bd24f7_1742963505404.jpeg',
  },
  {
    name: 'Emma Thompson',
    role: 'Head of Technology',
    image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&h=400&fit=crop&crop=face',
  },
  {
    name: 'David Kumar',
    role: 'Head of Operations',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face',
  },
];

export default function About() {
  const [particles, setParticles] = useState([]);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  React.useEffect(() => {
    const newParticles = Array.from({ length: 50 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 4 + 1,
      duration: Math.random() * 20 + 10,
      delay: Math.random() * 5,
    }));
    setParticles(newParticles);
  }, []);

  React.useEffect(() => {
    const handleMouseMove = (e) => {
      setMousePosition({
        x: (e.clientX / window.innerWidth) * 20 - 10,
        y: (e.clientY / window.innerHeight) * 20 - 10,
      });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <div className="relative min-h-screen overflow-hidden flex items-center">
        <div 
          className="absolute inset-0 bg-top bg-no-repeat"
          style={{ 
            backgroundImage: 'url(https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/2ef99cd7a_AdobeStock_328669930.jpg)',
            backgroundSize: '120%',
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#202020]/15 via-[#202020]/5 to-[#202020]/30" />

        {/* Animated Background Particles */}
        <div className="absolute inset-0">
          {particles.map((particle) => (
            <motion.div
              key={particle.id}
              className="absolute rounded-full bg-[#ff0080]/30"
              style={{
                left: `${particle.x}%`,
                top: `${particle.y}%`,
                width: particle.size,
                height: particle.size,
              }}
              animate={{
                y: [0, -30, 0],
                x: [0, Math.random() * 20 - 10, 0],
                opacity: [0.3, 0.8, 0.3],
                scale: [1, 1.2, 1],
              }}
              transition={{
                duration: particle.duration,
                delay: particle.delay,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />
          ))}
        </div>

        {/* 3D Animated Logo Background */}
        <motion.div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] opacity-10"
          style={{
            perspective: '1000px',
            transformStyle: 'preserve-3d',
          }}
          animate={{
            rotateY: 360,
            rotateX: [0, 10, 0, -10, 0],
            z: [0, 50, 0, -50, 0],
          }}
          transition={{
            rotateY: { duration: 20, repeat: Infinity, ease: "linear" },
            rotateX: { duration: 8, repeat: Infinity, ease: "easeInOut" },
            z: { duration: 6, repeat: Infinity, ease: "easeInOut" },
          }}
        >
          <motion.img
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/f447e746e_Inverse2x.png"
            alt="37Talent logo"
            className="w-full h-full object-contain"
            style={{
              filter: 'drop-shadow(0 0 60px rgba(255, 0, 128, 0.6))',
              transformStyle: 'preserve-3d',
            }}
            animate={{
              scale: [1, 1.1, 1],
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
        </motion.div>

        {/* Gradient Orbs with Parallax */}
        <motion.div 
          className="absolute top-1/4 right-1/4 w-96 h-96 bg-[#ff0080]/20 rounded-full blur-3xl"
          animate={{
            scale: [1, 1.2, 1],
            x: mousePosition.x * 2,
            y: mousePosition.y * 2,
          }}
          transition={{ scale: { duration: 4, repeat: Infinity }, x: { duration: 0.5 }, y: { duration: 0.5 } }}
        />
        <motion.div 
          className="absolute bottom-1/4 left-1/4 w-72 h-72 bg-[#c00060]/20 rounded-full blur-3xl"
          animate={{
            scale: [1, 1.3, 1],
            x: mousePosition.x * -1.5,
            y: mousePosition.y * -1.5,
          }}
          transition={{ scale: { duration: 5, repeat: Infinity }, x: { duration: 0.5 }, y: { duration: 0.5 } }}
        />
        <div className="relative z-10 w-full px-4 sm:px-6 h-full flex items-center bg-black">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-2xl"
          >
            {/* Tag */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="inline-block mb-6"
            >
              <span className="text-xs sm:text-sm font-medium text-white/70 uppercase tracking-wider">
                Who We Are
              </span>
            </motion.div>

            {/* Heading with mixed styling */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-6 leading-tight"
            >
              Discover <span className="text-white/50">how we build</span> <span className="text-white">exceptional teams</span>
            </motion.h1>

            {/* Description */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="text-base sm:text-lg text-white/80 mb-8 max-w-xl leading-relaxed"
            >
              37Talent builds elite, high-performing teams across technology, media and entertainment, connecting exceptional talent with the companies leading the 21st century.
            </motion.p>

            {/* CTA Button */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
            >
              <Link to={createPageUrl('Contact')}>
                <Button className="bg-gradient-to-r from-[#ff0080] to-[#c00060] hover:from-[#c00060] hover:to-[#ff0080] text-white px-6 sm:px-8 py-3 sm:py-4 rounded-lg font-semibold transition-all duration-300 shadow-lg shadow-[#ff0080]/25 hover:shadow-xl hover:shadow-[#ff0080]/40 text-sm sm:text-base">
                  Get in Touch
                </Button>
              </Link>
            </motion.div>
          </motion.div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black to-transparent" />
      </div>

      {/* Story Section */}
      <section className="py-16 md:py-20" style={{ backgroundColor: '#062D32' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid lg:grid-cols-2 gap-8 md:gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-white mb-4 sm:mb-6">
                37Talent Mission
              </h2>
              <div className="space-y-3 sm:space-y-4 text-sm sm:text-base text-[#ffebf5] leading-relaxed">
                <p>
                  Founded in 2021, 37Talent was created to challenge outdated hiring models and provide a more focused, high-performance approach to building world-class teams. We specialise exclusively in the technology, media, and entertainment sectors, working with organisations that are shaping the future of digital, data, platforms, and connected media.
                </p>
                <p>
                  Our strength lies in deep market understanding and long-standing relationships with highly sought-after professionals across engineering, commercial, product, data, and leadership functions. Through a trusted advisory approach, we help organisations secure the talent that strengthens capability, accelerates growth, and creates lasting competitive advantage, while supporting exceptional professionals in accessing career-defining opportunities.
                </p>
                <p>
                  Have a new hiring project? <Link to={createPageUrl('Contact')} className="text-[#FF0080] font-semibold hover:underline cursor-pointer">Let's talk.</Link>
                </p>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative"
            >
              <img
                src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=800&h=600&fit=crop"
                alt="Team collaboration"
                className="rounded-3xl shadow-xl"
              />
              <div className="absolute -bottom-6 -left-6 bg-gradient-to-r from-[#ff0080] to-[#c00060] rounded-2xl p-6 text-white shadow-lg">
                <div className="text-4xl font-bold">5+</div>
                <div className="text-cyan-100">Years of Excellence</div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
{/* Founder Section */}
<section className="py-16 md:py-20" style={{ backgroundColor: '#062D32' }}>
  <div className="max-w-7xl mx-auto px-4 sm:px-6">
    <div className="grid lg:grid-cols-2 gap-8 md:gap-12 items-center">
      <motion.div
        initial={{ opacity: 0, x: -30 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        className="relative order-2 lg:order-1"
      >
        <img
          src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/cfc837a96_1723245445163.jpeg"
          alt="Nick Squires, Founder"
          className="rounded-3xl shadow-xl"
        />
        <div className="absolute -bottom-6 -left-6 bg-gradient-to-r from-[#ff0080] to-[#c00060] rounded-2xl p-6 text-white shadow-lg">
          <div className="text-4xl font-bold">+16</div>
          <div className="text-cyan-100">Years Industry Experince</div>
        </div>
      </motion.div>
      <motion.div
        initial={{ opacity: 0, x: 30 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        className="order-1 lg:order-2"
      >
        <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-white mb-4 sm:mb-6">
          37Talent Founder
        </h2>
        <div className="space-y-3 sm:space-y-4 text-sm sm:text-base text-white leading-relaxed">
          <p>
            Nick Squires founded 37Talent with a clear mission: to transform how organisations identify, attract, and develop exceptional talent. With extensive experience in technology and media recruitment, and a strong track record of building high-performing teams for leading enterprises, Nick recognised a critical gap in the market for specialist, advisory-led talent solutions designed for high-growth sectors. This insight became the foundation of 37Talent.
          </p>
          <p>
            Having had the privilege of working as an external talent partner to some of the world's most recognised organisations, including Google, Yahoo, The Walt Disney Company, Quantcast, MiQ, The Trade Desk, Pandora Internet Radio and TikTok, Nick has built deep, long-standing relationships across the global technology, media, and digital ecosystem.
          </p>
          <p>
            Driven by a commitment to excellence and trusted partnerships, Nick has grown 37Talent into a valued partner for organisations across technology, media, and entertainment. His vision continues to shape the firm's approach: putting people first, building enduring relationships, and creating career-defining opportunities for the professionals and companies shaping the future.
          </p>
        </div>
      </motion.div>
    </div>
  </div>
</section>

{/* Timeline */}
<section className="py-20" style={{ backgroundColor: '#062D32' }}>
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Our Journey
            </h2>
          </motion.div>

          <div className="relative">
            {/* Timeline line */}
            <div className="hidden md:block absolute left-1/2 transform -translate-x-1/2 h-full w-0.5 bg-gradient-to-b from-[#ff0080] to-[#c00060]" />

            <div className="space-y-12">
              {milestones.map((milestone, index) => (
                <motion.div
                  key={milestone.year}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className={`flex flex-col md:flex-row items-center gap-8 ${
                    index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
                  }`}
                >
                  <div className={`md:w-1/2 ${index % 2 === 0 ? 'md:text-right' : 'md:text-left'}`}>
                    <div className="bg-gray-50 rounded-2xl p-6 inline-block">
                      <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-[#ff0080] to-[#c00060] mb-2">
                        {milestone.year}
                      </div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-1">{milestone.title}</h3>
                      <p className="text-gray-600">{milestone.description}</p>
                    </div>
                  </div>
                  <div className="hidden md:flex w-4 h-4 bg-gradient-to-r from-[#ff0080] to-[#c00060] rounded-full z-10" />
                  <div className="md:w-1/2" />
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-20" style={{ backgroundColor: '#062D32' }}>
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Leadership Team
            </h2>
            <p className="text-white text-lg max-w-2xl mx-auto">
              Meet the people driving our mission forward.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member, index) => (
              <motion.div
                key={member.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center group"
              >
                <div className="relative mb-4 overflow-hidden rounded-2xl">
                  <img
                    src={member.image}
                    alt={member.name}
                    className="w-full aspect-square object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
                <h3 className="text-lg font-semibold text-white">{member.name}</h3>
                <p className="text-white">{member.role}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-to-br from-[#202020] via-[#c00060] to-[#202020]">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
              Join Our Journey
            </h2>
            <p className="text-gray-400 text-lg mb-8 max-w-2xl mx-auto">
              Whether you're looking for your next opportunity or want to partner with us, 
              we'd love to hear from you.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to={createPageUrl('Jobs')}>
                <Button className="bg-gradient-to-r from-[#ff0080] to-[#c00060] hover:from-[#c00060] hover:to-[#ff0080] text-white px-8 py-6 rounded-xl font-semibold">
                  View Open Positions
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
              <Link to={createPageUrl('Contact')}>
                <Button variant="outline" className="border-white/30 text-white hover:bg-white/10 px-8 py-6 rounded-xl">
                  Contact Us
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
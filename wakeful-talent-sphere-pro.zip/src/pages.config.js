/**
 * pages.config.js - Page routing configuration
 * 
 * This file is AUTO-GENERATED. Do not add imports or modify PAGES manually.
 * Pages are auto-registered when you create files in the ./pages/ folder.
 * 
 * THE ONLY EDITABLE VALUE: mainPage
 * This controls which page is the landing page (shown when users visit the app).
 * 
 * Example file structure:
 * 
 *   import HomePage from './pages/HomePage';
 *   import Dashboard from './pages/Dashboard';
 *   import Settings from './pages/Settings';
 *   
 *   export const PAGES = {
 *       "HomePage": HomePage,
 *       "Dashboard": Dashboard,
 *       "Settings": Settings,
 *   }
 *   
 *   export const pagesConfig = {
 *       mainPage: "HomePage",
 *       Pages: PAGES,
 *   };
 * 
 * Example with Layout (wraps all pages):
 *
 *   import Home from './pages/Home';
 *   import Settings from './pages/Settings';
 *   import __Layout from './Layout.jsx';
 *
 *   export const PAGES = {
 *       "Home": Home,
 *       "Settings": Settings,
 *   }
 *
 *   export const pagesConfig = {
 *       mainPage: "Home",
 *       Pages: PAGES,
 *       Layout: __Layout,
 *   };
 *
 * To change the main page from HomePage to Dashboard, use find_replace:
 *   Old: mainPage: "HomePage",
 *   New: mainPage: "Dashboard",
 *
 * The mainPage value must match a key in the PAGES object exactly.
 */
import Contact from './pages/Contact';
import Home from './pages/Home';
import IndustryAdvertising from './pages/IndustryAdvertising';
import IndustryDataScience from './pages/IndustryDataScience';
import IndustryProfessionalServices from './pages/IndustryProfessionalServices';
import IndustryRetail from './pages/IndustryRetail';
import IndustrySaaS from './pages/IndustrySaaS';
import IndustryTechnology from './pages/IndustryTechnology';
import JobDetails from './pages/JobDetails';
import SubmitResume from './pages/SubmitResume';
import Jobs from './pages/Jobs';
import About from './pages/About';
import __Layout from './Layout.jsx';


export const PAGES = {
    "Contact": Contact,
    "Home": Home,
    "IndustryAdvertising": IndustryAdvertising,
    "IndustryDataScience": IndustryDataScience,
    "IndustryProfessionalServices": IndustryProfessionalServices,
    "IndustryRetail": IndustryRetail,
    "IndustrySaaS": IndustrySaaS,
    "IndustryTechnology": IndustryTechnology,
    "JobDetails": JobDetails,
    "SubmitResume": SubmitResume,
    "Jobs": Jobs,
    "About": About,
}

export const pagesConfig = {
    mainPage: "Home",
    Pages: PAGES,
    Layout: __Layout,
};
import React from 'react';
      import { motion } from 'framer-motion';
      import { BrainCircuit, ArrowRight, CheckCircle2 } from 'lucide-react';
      import { useQuery } from '@tanstack/react-query';
      import { base44 } from '@/api/base44Client';
      import { Button } from '@/components/ui/button';
      import { Link } from 'react-router-dom';
      import { createPageUrl } from '@/utils';
      import HorizontalFeaturedJobs from '@/components/home/HorizontalFeaturedJobs';
import ClientsSlider from '@/components/home/ClientsSlider';
import TestimonialsSection from '@/components/home/TestimonialsSection';

export default function IndustryAdvertising() {

        const { data: jobs = [], isLoading } = useQuery({
          queryKey: ['jobs'],
          queryFn: () => base44.entities.Job.list(),
        });

        const carouselItems = [
    {
      title: 'Limited Internal Expertise',
      description: 'Most media companies simply don\'t have the deep technical bench strength to accurately assess, interview, and successfully onboard high-calibre tech specialists. Without that specialised insight, you could be left second-guessing candidates and risking costly mis-hires and an unhappy CFO.',
    },
    {
      title: 'Fierce Competition & Lack Of Talent',
      description: 'In the non-stop race for elite talent, top performers hold all the power; they have endless choices and multiple offers. Tech giants, streaming leaders, and startups all chase the same scarce A-players who drive real impact in media. How can you differentiate your business to attract the best people in the industry?',
    },
    {
      title: 'Keeping Pace With Relentless Change',
      description: 'Platforms, AI, privacy laws, and content models change relentlessly. Competitive edge requires teams fluent in cutting-edge technology today, not tomorrow. Yet specialists who already "get it" remain scarce and difficult to attract. How can you overcome this hurdle?',
    },
    {
      title: 'Rare Hybrid Skillsets in Tech and Media',
      description: 'You\'re not just looking for strong coders or engineers. You need professionals who combine rock-solid technical expertise with a genuine understanding of media workflows, audience dynamics, content monetisation, and platform evolution. How can you unlock this talent?',
    },
    {
      title: 'Tough Assignments & Bespoke Briefs',
      description: 'When standard recruitment approaches fail for mission-critical, hard-to-fill roles with highly specific or bespoke requirements, you need experts to deliver tailored talent solutions that turn complex briefs into seamless, high-impact hires. How can you unlock the secret sauce to tap into this talent vein?',
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <div className="relative py-40 overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: 'url(https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/b498ad246_AdobeStock_1541671783.jpg)' }}
        />
        <div className="absolute inset-0 bg-black/20" />
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-5xl font-bold text-white mb-6">
              Media and Entertainment
            </h1>
            <p className="text-xl text-white max-w-3xl mb-8">
              Specialised recruitment for advertising agencies, adtech, social media, OOH, publisher and broadcast companies.
            </p>
            <Link to={createPageUrl('Contact')}>
              <Button className="bg-gradient-to-r from-[#ff0080] to-[#c00060] hover:from-[#c00060] hover:to-[#ff0080] text-white px-8 py-6 rounded-xl font-semibold">
                Get in Touch
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </div>

      {/* Companies Carousel */}
      <ClientsSlider />

      {/* Content */}
      <section className="py-20" style={{ backgroundColor: '#FF0080' }}>
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-12 items-start">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl font-bold text-white mb-6">
                Expert Talent for the Digital Age
              </h2>
              <p className="text-white mb-6 leading-relaxed">
                The advertising and digital landscape moves fast. We understand the unique demands of full-service agencies, performance marketing teams, and ad tech platforms. Our deep industry connections and expertise help you find the talent that drives campaigns, builds brands, and delivers results.
              </p>
              <p className="text-white mb-6 leading-relaxed">
                From leadership and sales executives to paid media specialists and data analysts, we source professionals who thrive in fast-paced, innovative environments.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <div className="bg-gray-50 rounded-2xl p-8">
                <h3 className="text-xl font-bold text-gray-900 mb-6">This fits our wheel house if you need to find people for the following positions.</h3>
                <ul className="space-y-4">
                  {[
                    'Leadership',
                    'Sales Leadership',
                    'Client Services',
                    'Paid Media & Performance Marketing Specialists',
                    'SEO & SEM Experts',
                    'Social Media Managers',
                    'Digital Strategists',
                    'Marketing Analytics & Data Science',
                    'Ad Tech Engineers & Product Managers',
                  ].map((role, i) => (
                    <li key={i} className="flex items-center gap-3">
                      <CheckCircle2 className="w-5 h-5 text-[#ff0080] shrink-0" />
                      <span className="text-gray-700">{role}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Carousel Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Unpacking your hiring challenges
            </h2>
          </motion.div>

          <div className="relative overflow-hidden">
            <motion.div
              className="flex gap-6"
              animate={{
                x: [0, -((carouselItems.length * (320 + 24)))],
              }}
              transition={{
                x: {
                  repeat: Infinity,
                  repeatType: "loop",
                  duration: 50,
                  ease: "linear",
                },
              }}
            >
              {[...carouselItems, ...carouselItems, ...carouselItems].map((item, index) => (
                <div key={index} className="w-80 flex-shrink-0 h-96">
                  <div className="bg-gradient-to-br from-[#FF0080] to-[#c00060] rounded-2xl p-8 shadow-lg h-full flex flex-col justify-start">
                    <h4 className="text-2xl font-bold text-white mb-4">{item.title}</h4>
                    <p className="text-base text-white leading-relaxed">{item.description}</p>
                  </div>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
        </section>

        {/* Featured Jobs */}
         <HorizontalFeaturedJobs jobs={jobs} isLoading={isLoading} />

         {/* Testimonials */}
         <TestimonialsSection />

         {/* CTA */}
        <section className="py-20 bg-gray-50">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">
            Ready to Build Your Team?
          </h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            Let's discuss your hiring needs and how we can help you find the perfect talent.
          </p>
          <Link to={createPageUrl('Contact')}>
            <Button className="bg-gradient-to-r from-[#ff0080] to-[#c00060] hover:from-[#c00060] hover:to-[#ff0080] text-white px-8 py-6 rounded-xl font-semibold">
              Get in Touch
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
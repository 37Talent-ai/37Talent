import React, { useEffect, useRef } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Autoplay } from 'swiper/modules';
import 'swiper/css';

const clients = [
  {
    name: 'Channel Factory',
    logo: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/f821e7dc3_channel_factory_logo1.jpeg',
  },
  {
    name: 'MiQ',
    logo: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/2932af1d5_miq_digital_logo.jpeg',
  },
  {
    name: 'Gumtree Group',
    logo: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/5c59e88b6_gumtreegroup_logo.jpeg',
  },
  {
    name: 'Kargo',
    logo: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/2b02c3401_kargo_logo.jpeg',
  },
  {
    name: 'Quantcast',
    logo: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/81f056638_quantcast_logo.jpeg',
  },
  {
    name: 'PubMatic',
    logo: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/075175f5d_1631326637962.jpeg',
  },
  {
    name: 'SambaTV',
    logo: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/cea750123_sambatv_logo.jpeg',
  },
  {
    name: 'This Is Flow',
    logo: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/68a15046c_thisisflow_logo.jpeg',
  },
  {
    name: 'AvenueC',
    logo: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/e44aedd19_avenue_c_agency_logo1.jpeg',
  },
  {
    name: 'theTradeDesk',
    logo: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/534d003c0_the_trade_desk_logo.jpeg',
  },
  {
    name: 'Carsguide',
    logo: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/d7d449f2f_carsguide_logo.jpeg',
  },
  {
    name: 'VDX.tv',
    logo: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/4f725be70_vdx_tv_logo.jpeg',
  },
  {
    name: 'StackAdapt',
    logo: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/fcc879a43_stackadapt_logo.jpeg',
  },
  {
    name: 'Cashrewards',
    logo: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/2eff6781e_cashrewards_logo.jpeg',
  },
  {
    name: 'The Guardian',
    logo: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/2f6106b92_guardian_news__media_logo.jpeg',
  },
  {
    name: 'Silverpush',
    logo: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/4f205e114_silverpush_logo.jpeg',
  },
  {
    name: 'Criteo',
    logo: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/2598d283c_criteo_logo.jpeg',
  },
  {
    name: 'Samsung Ads',
    logo: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6983e8c149d29c69536d7d1d/bfb9fa269_samsung_ads_logo.jpeg',
  },
  ];

export default function ClientsSlider() {
  const swiperRef = useRef(null);
  const duplicatedClients = [...clients, ...clients];

  return (
    <section className="pt-16 md:pt-20 pb-8 md:pb-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-10 md:mb-12">
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-gray-900 mb-3 sm:mb-4">
            Companies We've Helped
          </h2>
          <p className="text-sm sm:text-base md:text-lg text-gray-600">
            Trusted by leading organisations across industries.
          </p>
        </div>

        <style>{`
          .logo-ticker {
            width: 100%;
            overflow: hidden;
            padding: 20px 0;
          }
          .swiper-slide {
            width: auto !important;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            gap: 12px;
          }
          .swiper-slide img {
            height: 48px;
            width: auto;
            max-width: 180px;
            object-fit: contain;
          }
          .swiper-slide-text {
            font-size: 0.75rem;
            font-weight: 600;
            color: #374151;
            text-align: center;
            max-width: 150px;
            line-clamp: 2;
          }
          @media (max-width: 768px) {
            .swiper-slide img {
              height: 40px;
              max-width: 140px;
            }
            .swiper-slide-text {
              font-size: 0.7rem;
            }
          }
        `}</style>

        <div className="logo-ticker">
          <Swiper
            ref={swiperRef}
            modules={[Autoplay]}
            slidesPerView="auto"
            spaceBetween={24}
            loop={true}
            loopedSlides={clients.length}
            speed={8000}
            autoplay={{
              delay: 0,
              disableOnInteraction: false,
            }}
            freeMode={{
              enabled: true,
              momentum: false,
            }}
            grabCursor={true}
            allowTouchMove={true}
            touchRatio={1}
            touchAngle={45}
            preventClicks={false}
            onMouseEnter={() => {
              if (swiperRef.current?.swiper?.autoplay) {
                swiperRef.current.swiper.autoplay.stop();
              }
            }}
            onMouseLeave={() => {
              if (swiperRef.current?.swiper?.autoplay) {
                swiperRef.current.swiper.autoplay.start();
              }
            }}
          >
            {duplicatedClients.map((client, index) => (
              <SwiperSlide key={`${client.name}-${index}`}>
                <div className="flex flex-col items-center justify-center gap-3 px-3">
                  <img
                    src={client.logo}
                    alt={client.name}
                    loading="lazy"
                    onError={(e) => {
                      e.target.src = `https://via.placeholder.com/100?text=${client.name}`;
                    }}
                  />
                  <span className="swiper-slide-text">{client.name}</span>
                </div>
              </SwiperSlide>
            ))}
          </Swiper>
        </div>
      </div>
    </section>
  );
}